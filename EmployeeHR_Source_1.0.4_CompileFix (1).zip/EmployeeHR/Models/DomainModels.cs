namespace EmployeeHR.Models;

public sealed class Employee
{
    public long Id { get; set; }
    public string EmployeeNumber { get; set; } = "";
    public string ArabicName { get; set; } = "";
    public string EnglishName { get; set; } = "";
    public string Nationality { get; set; } = "";
    public string NationalId { get; set; } = "";
    public DateTime? IqamaExpiry { get; set; }
    public DateTime? BirthDate { get; set; }
    public string Mobile { get; set; } = "";
    public string JobTitle { get; set; } = "";
    public string Department { get; set; } = "";
    public DateTime StartDate { get; set; } = DateTime.Today;
    public string Status { get; set; } = "على رأس العمل";
    public string ContractType { get; set; } = "محدد المدة";
    public DateTime? ContractStart { get; set; }
    public DateTime? ContractEnd { get; set; }
    public int ProbationDays { get; set; }
    public string Notes { get; set; } = "";
    public override string ToString() => $"{EmployeeNumber} - {ArabicName}";
}

public sealed class ContractRecord
{
    public long Id { get; set; }
    public long EmployeeId { get; set; }
    public string ContractType { get; set; } = "محدد المدة";
    public DateTime StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public int ProbationDays { get; set; }
    public DateTime EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }
    public string Notes { get; set; } = "";
}

public sealed class SalaryRecord
{
    public long Id { get; set; }
    public long EmployeeId { get; set; }
    public DateTime EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }
    public decimal BasicSalary { get; set; }
    public decimal HousingAllowance { get; set; }
    public decimal TransportationAllowance { get; set; }
    public decimal FoodAllowance { get; set; }
    public decimal OtherFixedAllowances { get; set; }
    public decimal Commissions { get; set; }
    public decimal VariableAllowances { get; set; }
    public decimal GrossWage => BasicSalary + HousingAllowance + TransportationAllowance + FoodAllowance + OtherFixedAllowances + Commissions + VariableAllowances;
}

public sealed class SalaryComponentDefinition
{
    public string Code { get; set; } = "";
    public string ArabicName { get; set; } = "";
    public bool IncludeInEosb { get; set; }
    public bool IncludeInLeave { get; set; }
    public bool IncludeInOther { get; set; }
}

public sealed class LeaveRequest
{
    public long Id { get; set; }
    public long EmployeeId { get; set; }
    public string EmployeeName { get; set; } = "";
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public decimal DaysCount { get; set; }
    public string LeaveType { get; set; } = "إجازة سنوية";
    public string Status { get; set; } = "مسودة";
    public string Notes { get; set; } = "";
}

public sealed class UnpaidLeave
{
    public long Id { get; set; }
    public long EmployeeId { get; set; }
    public string EmployeeName { get; set; } = "";
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public int DaysCount { get; set; }
    public string Reason { get; set; } = "";
    public string Notes { get; set; } = "";
    public bool AffectsService { get; set; }
    public bool AffectsLeaveAccrual { get; set; }
    public bool ContractSuspended { get; set; }
}

public sealed class LeaveLedgerEntry
{
    public long Id { get; set; }
    public long EmployeeId { get; set; }
    public DateTime EntryDate { get; set; }
    public string EntryType { get; set; } = "";
    public string Description { get; set; } = "";
    public decimal Accrued { get; set; }
    public decimal Used { get; set; }
    public decimal Adjustment { get; set; }
    public decimal RunningBalance { get; set; }
    public bool SystemGenerated { get; set; }
    public long? SourceId { get; set; }
}

public sealed class LeaveBalanceResult
{
    public decimal OpeningBalance { get; set; }
    public decimal Accrued { get; set; }
    public decimal Used { get; set; }
    public decimal FutureApproved { get; set; }
    public decimal Adjustments { get; set; }
    public decimal CurrentBalance => OpeningBalance + Accrued + Adjustments - Used;
    public string CalculationDetails { get; set; } = "";
}

public sealed class ServicePeriodResult
{
    public int TotalCalendarDays { get; set; }
    public int ExcludedDays { get; set; }
    public int NetServiceDays { get; set; }
    public int Years { get; set; }
    public int Months { get; set; }
    public int Days { get; set; }
    public decimal DecimalYears { get; set; }
    public string Display => $"{Years} سنة و{Months} شهر و{Days} يوم";
}

public sealed class EosbResult
{
    public decimal EligibleMonthlyWage { get; set; }
    public ServicePeriodResult ServicePeriod { get; set; } = new();
    public decimal FirstFiveYearsAmount { get; set; }
    public decimal YearsAboveFiveAmount { get; set; }
    public decimal BasicAward { get; set; }
    public decimal EntitlementRate { get; set; }
    public decimal FinalAward { get; set; }
    public string Details { get; set; } = "";
}

public sealed class TerminationRecord
{
    public long Id { get; set; }
    public long EmployeeId { get; set; }
    public DateTime LastWorkingDay { get; set; }
    public string Reason { get; set; } = "";
    public string InitiatedBy { get; set; } = "";
    public string LegalArticle { get; set; } = "";
    public string Notes { get; set; } = "";
    public bool HasContractCompensationClause { get; set; }
    public string CompensationMethod { get; set; } = "";
    public decimal CompensationAmount { get; set; }
}

public sealed class FinalSettlementResult
{
    public Employee Employee { get; set; } = new();
    public DateTime LastWorkingDay { get; set; }
    public ServicePeriodResult ServicePeriod { get; set; } = new();
    public decimal LastGrossMonthlyWage { get; set; }
    public decimal EosbEligibleMonthlyWage { get; set; }
    public decimal LeaveEligibleMonthlyWage { get; set; }
    public decimal SalaryUntilLastDay { get; set; }
    public decimal Eosb { get; set; }
    public decimal LeaveDays { get; set; }
    public decimal LeaveDailyRate { get; set; }
    public decimal LeaveValue { get; set; }
    public decimal TerminationCompensation { get; set; }
    public decimal PriorSalaryDue { get; set; }
    public decimal AllowancesDue { get; set; }
    public decimal CommissionsDue { get; set; }
    public decimal ExpensesDue { get; set; }
    public decimal OtherEntitlements { get; set; }
    public decimal Advances { get; set; }
    public decimal Loans { get; set; }
    public decimal StatutoryDeductions { get; set; }
    public decimal EmployerReceivables { get; set; }
    public decimal OtherDeductions { get; set; }
    public decimal TotalEntitlements => SalaryUntilLastDay + Eosb + LeaveValue + TerminationCompensation + PriorSalaryDue + AllowancesDue + CommissionsDue + ExpensesDue + OtherEntitlements;
    public decimal TotalDeductions => Advances + Loans + StatutoryDeductions + EmployerReceivables + OtherDeductions;
    public decimal NetSettlement => TotalEntitlements - TotalDeductions;
    public string CalculationDetails { get; set; } = "";
}

public sealed class DashboardMetrics
{
    public int TotalEmployees { get; set; }
    public int ActiveEmployees { get; set; }
    public int TerminatedEmployees { get; set; }
    public int ContractsExpiringSoon { get; set; }
    public int IqamasExpiringSoon { get; set; }
    public int CurrentLeaves { get; set; }
    public int UpcomingLeaves { get; set; }
    public decimal TotalLeaveBalances { get; set; }
    public int HighLeaveBalanceEmployees { get; set; }
    public int ApproachingFiveYears { get; set; }
}
