param(
    [string]$Configuration = "Release",
    [string]$Runtime = "win-x64"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectFile = Join-Path $ProjectRoot "EmployeeHR.csproj"
$LocalDotnet = Join-Path $ProjectRoot ".build-dotnet"
$ReleaseRoot = Join-Path $ProjectRoot "Release"
$PortableDir = Join-Path $ReleaseRoot "EmployeeHR_Portable"
$ZipFile = Join-Path $ReleaseRoot "EmployeeHR_Portable.zip"

function Get-Dotnet8 {
    $candidate = Get-Command dotnet -ErrorAction SilentlyContinue
    if ($candidate) {
        try {
            $sdks = & $candidate.Source --list-sdks 2>$null
            if ($LASTEXITCODE -eq 0 -and ($sdks | Where-Object { $_ -match '^8\.' })) {
                return $candidate.Source
            }
        }
        catch {
            # Continue and try local SDK.
        }
    }

    $localExe = Join-Path $LocalDotnet "dotnet.exe"
    if (Test-Path $localExe) {
        $sdks = & $localExe --list-sdks 2>$null
        if ($LASTEXITCODE -eq 0 -and ($sdks | Where-Object { $_ -match '^8\.' })) {
            return $localExe
        }
    }

    Write-Host "Microsoft .NET 8 SDK was not found." -ForegroundColor Yellow
    Write-Host "Downloading a private copy into this project folder. No admin rights or Windows installation are required." -ForegroundColor Yellow

    New-Item -ItemType Directory -Force -Path $LocalDotnet | Out-Null

    # PowerShell 5.1 on older Windows installations may otherwise negotiate an old TLS version.
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $installScript = Join-Path $env:TEMP "dotnet-install-EmployeeHR.ps1"
    Invoke-WebRequest -UseBasicParsing -Uri "https://dot.net/v1/dotnet-install.ps1" -OutFile $installScript

    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installScript `
        -Channel 8.0 `
        -Quality GA `
        -Architecture x64 `
        -InstallDir $LocalDotnet `
        -NoPath | Out-Host

    if ($LASTEXITCODE -ne 0) {
        throw "The local .NET 8 SDK download/install failed."
    }

    if (-not (Test-Path $localExe)) {
        throw "dotnet.exe was not found after installing the local .NET 8 SDK."
    }

    return $localExe
}

if (-not (Test-Path $ProjectFile)) {
    throw "EmployeeHR.csproj was not found in: $ProjectRoot"
}

$dotnet = Get-Dotnet8
$dotnetVersion = & $dotnet --version
Write-Host "Using .NET SDK: $dotnetVersion" -ForegroundColor Cyan

if (Test-Path $PortableDir) {
    Remove-Item $PortableDir -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $PortableDir | Out-Null

Write-Host "Publishing EmployeeHR as a self-contained single-file Windows application..." -ForegroundColor Cyan

& $dotnet publish $ProjectFile `
    -c $Configuration `
    -r $Runtime `
    --self-contained true `
    -p:PublishSingleFile=true `
    -p:IncludeNativeLibrariesForSelfExtract=true `
    -p:EnableCompressionInSingleFile=true `
    -p:PublishReadyToRun=true `
    -p:PublishTrimmed=false `
    -p:DebugType=None `
    -p:DebugSymbols=false `
    -o $PortableDir

if ($LASTEXITCODE -ne 0) {
    throw "dotnet publish failed. Review the compiler messages above."
}

$exe = Join-Path $PortableDir "EmployeeHR.exe"
if (-not (Test-Path $exe)) {
    throw "EmployeeHR.exe was not created."
}

New-Item -ItemType Directory -Force -Path (Join-Path $PortableDir "Backups") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $PortableDir "Exports") | Out-Null

Get-ChildItem $PortableDir -File | Where-Object { $_.Extension -eq '.pdb' } | Remove-Item -Force

$hash = (Get-FileHash $exe -Algorithm SHA256).Hash
$sizeMb = [Math]::Round((Get-Item $exe).Length / 1MB, 2)

$manifest = @"
EmployeeHR Portable Build
Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Runtime: $Runtime
SDK: $dotnetVersion
Framework: .NET 8 WPF Self-Contained Single File
Executable: EmployeeHR.exe
SizeMB: $sizeMb
SHA256: $hash
Database: EmployeeHR.db is created beside the EXE on first run.
"@

Set-Content -Path (Join-Path $PortableDir "BUILD-MANIFEST.txt") -Value $manifest -Encoding ASCII

if (Test-Path $ZipFile) {
    Remove-Item $ZipFile -Force
}
Compress-Archive -Path (Join-Path $PortableDir '*') -DestinationPath $ZipFile -CompressionLevel Optimal

Write-Host ""
Write-Host "BUILD SUCCESSFUL" -ForegroundColor Green
Write-Host "Executable:" -ForegroundColor Green
Write-Host "  $exe"
Write-Host "Portable ZIP:" -ForegroundColor Green
Write-Host "  $ZipFile"
Write-Host "SHA256: $hash"
