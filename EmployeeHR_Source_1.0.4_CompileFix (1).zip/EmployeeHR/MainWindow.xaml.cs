using System.Windows;
using System.Windows.Controls;
using EmployeeHR.Views;

namespace EmployeeHR;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Show("Dashboard");
    }

    private void Nav_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button b && b.Tag is string key) Show(key);
    }

    private void Show(string key)
    {
        MainContent.Content = key switch
        {
            "Employees" => new EmployeesView(),
            "Contracts" => new ContractsView(),
            "Salaries" => new SalariesView(),
            "Leaves" => new LeavesView(),
            "LeaveBalances" => new LeaveBalancesView(),
            "UnpaidLeaves" => new UnpaidLeavesView(),
            "Termination" => new TerminationView(),
            "Settlement" => new FinalSettlementView(),
            "Reports" => new ReportsView(),
            "Settings" => new SettingsView(),
            _ => new DashboardView()
        };
        PageTitle.Text = key switch
        {
            "Employees" => "الموظفون", "Contracts" => "العقود", "Salaries" => "الرواتب وتاريخ الرواتب", "Leaves" => "الإجازات السنوية",
            "LeaveBalances" => "أرصدة وسجل الإجازات", "UnpaidLeaves" => "الإجازات بدون أجر", "Termination" => "انتهاء الخدمة", "Settlement" => "التصفية النهائية",
            "Reports" => "التقارير والتصدير", "Settings" => "القواعد النظامية والإعدادات", _ => "لوحة المعلومات"
        };
    }
}
