using EmployeeHR.Data;
using EmployeeHR.Data.Migrations;
using EmployeeHR.Utilities;

namespace EmployeeHR.Services;

public static class DatabaseMigrationService
{
    public static void Initialize()
    {
        Directory.CreateDirectory(AppPaths.BackupsDirectory);
        Directory.CreateDirectory(AppPaths.ExportsDirectory);
        using var db = Db.Open();
        db.Execute("CREATE TABLE IF NOT EXISTS SchemaVersion(Version INTEGER NOT NULL PRIMARY KEY, AppliedAt TEXT NOT NULL);");
        var current = Convert.ToInt32(db.Scalar("SELECT COALESCE(MAX(Version),0) FROM SchemaVersion;") ?? 0);
        if (current < Migration001.Version)
        {
            db.Begin();
            try
            {
                foreach (var statement in SplitSql(Migration001.Sql))
                    db.Execute(statement);
                db.Execute("INSERT INTO SchemaVersion(Version,AppliedAt) VALUES(@v,@d);", new Dictionary<string, object?> { ["v"] = Migration001.Version, ["d"] = DateTime.Now.ToString("s") });
                SeedDefaults(db);
                db.Commit();
            }
            catch
            {
                db.Rollback();
                throw;
            }
        }
        else
        {
            SeedDefaults(db);
        }
    }

    private static IEnumerable<string> SplitSql(string sql)
        => sql.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Where(x => !string.IsNullOrWhiteSpace(x));

    private static void SeedDefaults(SqliteConnectionLite db)
    {
        var now = DateTime.Now.ToString("s");
        void Setting(string key, string value) => db.Execute("INSERT OR IGNORE INTO Settings(Key,Value,UpdatedAt) VALUES(@k,@v,@u);", new Dictionary<string, object?> { ["k"] = key, ["v"] = value, ["u"] = now });
        Setting("LeaveDayMode", "CalendarDays");
        Setting("WeekendDays", "Friday,Saturday");
        Setting("ExpiryWarningDays", "60");
        Setting("HighLeaveBalanceThreshold", "45");
        Setting("DailyWageDivisor", "30");
        Setting("Currency", "SAR");
        Setting("BackupRetention", "30");
        Setting("UseArabicIndicDigits", "0");

        var components = new[]
        {
            ("BasicSalary","الراتب الأساسي",1,1,1),
            ("HousingAllowance","بدل السكن",1,1,1),
            ("TransportationAllowance","بدل النقل",1,1,1),
            ("FoodAllowance","بدل الطعام / الإعاشة",1,1,1),
            ("OtherFixedAllowances","بدلات ثابتة أخرى",1,1,1),
            ("Commissions","العمولات",1,1,1),
            ("VariableAllowances","بدلات متغيرة",1,1,1)
        };
        foreach (var c in components)
            db.Execute("INSERT OR IGNORE INTO SalaryComponents(Code,ArabicName,IncludeInEosb,IncludeInLeave,IncludeInOther) VALUES(@c,@n,@e,@l,@o);", new Dictionary<string, object?> { ["c"] = c.Item1, ["n"] = c.Item2, ["e"] = c.Item3, ["l"] = c.Item4, ["o"] = c.Item5 });

        if (Convert.ToInt32(db.Scalar("SELECT COUNT(*) FROM LeaveRules;") ?? 0) == 0)
        {
            db.Execute("INSERT INTO LeaveRules(RuleName,MinServiceYears,MaxServiceYears,AnnualEntitlementDays,EffectiveFrom,EffectiveTo,ArticleRef,Notes) VALUES('قبل خمس سنوات',0,5,21,'2005-09-27',NULL,'المادة 109','قاعدة افتراضية قابلة للتعديل');");
            db.Execute("INSERT INTO LeaveRules(RuleName,MinServiceYears,MaxServiceYears,AnnualEntitlementDays,EffectiveFrom,EffectiveTo,ArticleRef,Notes) VALUES('بعد خمس سنوات متصلة',5,NULL,30,'2005-09-27',NULL,'المادة 109','قاعدة افتراضية قابلة للتعديل');");
        }
        if (Convert.ToInt32(db.Scalar("SELECT COUNT(*) FROM EosbRules;") ?? 0) == 0)
        {
            db.Execute("INSERT INTO EosbRules(RuleName,SegmentStartYears,SegmentEndYears,MonthsPerServiceYear,EffectiveFrom,ArticleRef,Notes) VALUES('أول خمس سنوات',0,5,0.5,'2005-09-27','المادة 84','نصف أجر شهر عن كل سنة');");
            db.Execute("INSERT INTO EosbRules(RuleName,SegmentStartYears,SegmentEndYears,MonthsPerServiceYear,EffectiveFrom,ArticleRef,Notes) VALUES('ما زاد على خمس سنوات',5,NULL,1.0,'2005-09-27','المادة 84','أجر شهر عن كل سنة');");
        }
        if (Convert.ToInt32(db.Scalar("SELECT COUNT(*) FROM ResignationEntitlementRules;") ?? 0) == 0)
        {
            db.Execute("INSERT INTO ResignationEntitlementRules(RuleName,MinServiceYears,MaxServiceYears,EntitlementRate,MinInclusive,MaxInclusive,EffectiveFrom,ArticleRef,Notes) VALUES('أقل من سنتين',0,2,0,1,0,'2005-09-27','المادة 85','لا استحقاق في الاستقالة قبل سنتين وفق القاعدة العامة');");
            db.Execute("INSERT INTO ResignationEntitlementRules(RuleName,MinServiceYears,MaxServiceYears,EntitlementRate,MinInclusive,MaxInclusive,EffectiveFrom,ArticleRef,Notes) VALUES('من سنتين إلى خمس',2,5,0.3333333333,1,1,'2005-09-27','المادة 85','ثلث المكافأة');");
            db.Execute("INSERT INTO ResignationEntitlementRules(RuleName,MinServiceYears,MaxServiceYears,EntitlementRate,MinInclusive,MaxInclusive,EffectiveFrom,ArticleRef,Notes) VALUES('أكثر من خمس وأقل من عشر',5,10,0.6666666667,0,0,'2005-09-27','المادة 85','ثلثا المكافأة');");
            db.Execute("INSERT INTO ResignationEntitlementRules(RuleName,MinServiceYears,MaxServiceYears,EntitlementRate,MinInclusive,MaxInclusive,EffectiveFrom,ArticleRef,Notes) VALUES('عشر سنوات فأكثر',10,NULL,1,1,0,'2005-09-27','المادة 85','المكافأة كاملة');");
        }
        var reasons = new (string name,string by,string article,int full)[]
        {
            ("انتهاء العقد","انتهاء المدة","",0),("استقالة","الموظف","المادة 85",0),("إنهاء من صاحب العمل","صاحب العمل","",0),
            ("اتفاق الطرفين","الطرفان","",0),("تقاعد","بحكم النظام/الاتفاق","",0),("وفاة","سبب نظامي","",0),("قوة قاهرة","سبب خارج الإرادة","المادة 87",1),
            ("إنهاء خلال فترة التجربة","بحسب الحالة","المادة 54",0),("إنهاء وفق المادة 80","صاحب العمل","المادة 80",0),("إنهاء وفق مادة نظامية","بحسب الحالة","",0),("ترك العمل وفق المادة 81","الموظف","المادة 81",1),("استقالة - استثناء المادة 87 (الزواج)","الموظف","المادة 87",1),("استقالة - استثناء المادة 87 (الوضع)","الموظف","المادة 87",1),("سبب آخر","بحسب الحالة","",0)
        };
        foreach (var r in reasons)
            db.Execute("INSERT OR IGNORE INTO TerminationReasons(ArabicName,DefaultInitiatedBy,LegalArticle,FullEosbException,Active) VALUES(@n,@b,@a,@f,1);", new Dictionary<string, object?> { ["n"] = r.name, ["b"] = r.by, ["a"] = r.article, ["f"] = r.full });
    }
}
