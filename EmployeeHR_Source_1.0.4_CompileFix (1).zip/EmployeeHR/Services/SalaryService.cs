using EmployeeHR.Models;
using EmployeeHR.Repositories;

namespace EmployeeHR.Services;

public sealed class SalaryService
{
    private readonly SalaryRepository _repo=new();
    public SalaryRecord? GetAt(long employeeId,DateTime date)=>_repo.GetAt(employeeId,date);
    public List<SalaryRecord> GetHistory(long employeeId)=>_repo.GetHistory(employeeId);
    public List<SalaryComponentDefinition> GetComponents()=>_repo.GetComponents();
    public void UpdateComponent(SalaryComponentDefinition c){_repo.UpdateComponent(c);AuditService.Log("تعديل مكون راتب","SalaryComponent",c.Code,$"EOSB={c.IncludeInEosb}, Leave={c.IncludeInLeave}, Other={c.IncludeInOther}");}
    public long Add(SalaryRecord s)
    {
        if(s.EmployeeId<=0) throw new InvalidOperationException("اختر الموظف.");
        if(new[]{s.BasicSalary,s.HousingAllowance,s.TransportationAllowance,s.FoodAllowance,s.OtherFixedAllowances,s.Commissions,s.VariableAllowances}.Any(x=>x<0)) throw new InvalidOperationException("لا يمكن إدخال مكون راتب بقيمة سالبة.");
        var id=_repo.Add(s); AuditService.Log("إضافة راتب تاريخي","Salary",id.ToString(),$"موظف {s.EmployeeId} - إجمالي {s.GrossWage:N2}"); return id;
    }

    public decimal GetEligibleWage(long employeeId,DateTime date,string purpose)
        => GetWageBreakdown(employeeId,date,purpose).Where(x=>x.Included).Sum(x=>x.Amount);

    public List<(string Code,string Name,decimal Amount,bool Included)> GetWageBreakdown(long employeeId,DateTime date,string purpose)
    {
        var s=_repo.GetAt(employeeId,date) ?? new SalaryRecord();
        var defs=_repo.GetComponents().ToDictionary(x=>x.Code,StringComparer.OrdinalIgnoreCase);
        bool Include(string code)=>defs.TryGetValue(code,out var d) && purpose switch { "EOSB"=>d.IncludeInEosb,"Leave"=>d.IncludeInLeave,_=>d.IncludeInOther };
        string Name(string code,string fallback)=>defs.TryGetValue(code,out var d)?d.ArabicName:fallback;
        return new()
        {
            ("BasicSalary",Name("BasicSalary","الراتب الأساسي"),s.BasicSalary,Include("BasicSalary")),
            ("HousingAllowance",Name("HousingAllowance","بدل السكن"),s.HousingAllowance,Include("HousingAllowance")),
            ("TransportationAllowance",Name("TransportationAllowance","بدل النقل"),s.TransportationAllowance,Include("TransportationAllowance")),
            ("FoodAllowance",Name("FoodAllowance","بدل الطعام/الإعاشة"),s.FoodAllowance,Include("FoodAllowance")),
            ("OtherFixedAllowances",Name("OtherFixedAllowances","بدلات ثابتة أخرى"),s.OtherFixedAllowances,Include("OtherFixedAllowances")),
            ("Commissions",Name("Commissions","العمولات"),s.Commissions,Include("Commissions")),
            ("VariableAllowances",Name("VariableAllowances","بدلات متغيرة"),s.VariableAllowances,Include("VariableAllowances"))
        };
    }
}
