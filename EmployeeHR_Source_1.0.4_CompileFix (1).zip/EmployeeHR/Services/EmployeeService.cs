using EmployeeHR.Models;
using EmployeeHR.Repositories;

namespace EmployeeHR.Services;

public sealed class EmployeeService
{
    private readonly EmployeeRepository _repo=new();
    public List<Employee> GetAll()=>_repo.GetAll();
    public List<Employee> GetActive()=>_repo.GetActive();
    public Employee? Get(long id)=>_repo.Get(id);
    public long Save(Employee e)
    {
        if(string.IsNullOrWhiteSpace(e.EmployeeNumber)) throw new InvalidOperationException("رقم الموظف مطلوب.");
        if(string.IsNullOrWhiteSpace(e.ArabicName)) throw new InvalidOperationException("اسم الموظف بالعربية مطلوب.");
        if(string.IsNullOrWhiteSpace(e.NationalId)) throw new InvalidOperationException("رقم الهوية أو الإقامة مطلوب.");
        if(e.StartDate>DateTime.Today.AddYears(1)) throw new InvalidOperationException("تاريخ بداية العمل غير منطقي.");
        try
        {
            var id=_repo.Save(e);
            AuditService.Log(e.Id==0?"إضافة موظف":"تعديل موظف","Employee",id.ToString(),$"{e.EmployeeNumber} - {e.ArabicName}");
            return id;
        }
        catch(InvalidOperationException){throw;}
        catch(Exception ex) when(ex.Message.Contains("UNIQUE",StringComparison.OrdinalIgnoreCase))
        { throw new InvalidOperationException("رقم الموظف أو رقم الهوية/الإقامة مسجل مسبقًا.",ex); }
    }
}
