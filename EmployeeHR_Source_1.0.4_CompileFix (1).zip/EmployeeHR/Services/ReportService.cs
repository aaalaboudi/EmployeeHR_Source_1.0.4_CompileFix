using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Markup;
using EmployeeHR.Calculation;
using EmployeeHR.Data;
using EmployeeHR.Models;
using EmployeeHR.Utilities;

namespace EmployeeHR.Services;

public sealed class ReportService
{
    public List<Dictionary<string, object?>> GetReport(string reportKey)
    {
        using var db = Db.Open();
        return reportKey switch
        {
            "Employees" => db.Query("SELECT EmployeeNumber 'رقم الموظف',ArabicName 'الاسم',NationalId 'الهوية/الإقامة',Nationality 'الجنسية',JobTitle 'المسمى',Department 'القسم',StartDate 'بداية العمل',Status 'الحالة' FROM Employees ORDER BY ArabicName;"),
            "LeaveTransactions" => db.Query(@"SELECT e.EmployeeNumber 'رقم الموظف',e.ArabicName 'الاسم',l.StartDate 'من',l.EndDate 'إلى',l.DaysCount 'الأيام',l.LeaveType 'النوع',l.Status 'الحالة',l.Notes 'ملاحظات' FROM LeaveRequests l JOIN Employees e ON e.Id=l.EmployeeId ORDER BY l.StartDate DESC;"),
            "UnpaidLeave" => db.Query(@"SELECT e.EmployeeNumber 'رقم الموظف',e.ArabicName 'الاسم',u.StartDate 'من',u.EndDate 'إلى',u.DaysCount 'الأيام',u.Reason 'السبب',CASE WHEN u.AffectsService=1 THEN 'نعم' ELSE 'لا' END 'تؤثر على الخدمة',CASE WHEN u.AffectsLeaveAccrual=1 THEN 'نعم' ELSE 'لا' END 'تؤثر على الاستحقاق',CASE WHEN u.ContractSuspended=1 THEN 'نعم' ELSE 'لا' END 'العقد موقوف' FROM UnpaidLeaves u JOIN Employees e ON e.Id=u.EmployeeId ORDER BY u.StartDate DESC;"),
            "SalaryHistory" => db.Query(@"SELECT e.EmployeeNumber 'رقم الموظف',e.ArabicName 'الاسم',s.EffectiveFrom 'ساري من',s.EffectiveTo 'ساري إلى',s.BasicSalary 'الأساسي',s.HousingAllowance 'السكن',s.TransportationAllowance 'النقل',s.FoodAllowance 'الإعاشة',s.OtherFixedAllowances 'ثابت أخرى',s.Commissions 'عمولات',s.VariableAllowances 'متغيرة',(s.BasicSalary+s.HousingAllowance+s.TransportationAllowance+s.FoodAllowance+s.OtherFixedAllowances+s.Commissions+s.VariableAllowances) 'الإجمالي' FROM SalaryHistory s JOIN Employees e ON e.Id=s.EmployeeId ORDER BY e.ArabicName,s.EffectiveFrom DESC;"),
            "ContractExpiry" => db.Query(@"SELECT EmployeeNumber 'رقم الموظف',ArabicName 'الاسم',ContractType 'نوع العقد',ContractStart 'بداية العقد',ContractEnd 'نهاية العقد',CAST(julianday(ContractEnd)-julianday(date('now','localtime')) AS INTEGER) 'الأيام المتبقية' FROM Employees WHERE Status='على رأس العمل' AND ContractEnd IS NOT NULL ORDER BY ContractEnd;"),
            "IqamaExpiry" => db.Query(@"SELECT EmployeeNumber 'رقم الموظف',ArabicName 'الاسم',NationalId 'رقم الإقامة/الهوية',IqamaExpiry 'تاريخ الانتهاء',CAST(julianday(IqamaExpiry)-julianday(date('now','localtime')) AS INTEGER) 'الأيام المتبقية' FROM Employees WHERE Status='على رأس العمل' AND IqamaExpiry IS NOT NULL ORDER BY IqamaExpiry;"),
            "Audit" => AuditService.GetRecent(5000),
            _ => new List<Dictionary<string, object?>>()
        };
    }

    public List<Dictionary<string, object?>> GetLeaveBalanceReport(DateTime asOf)
    {
        var employees = new EmployeeService().GetAll(); var calc = new LeaveCalculationService(); var rows = new List<Dictionary<string, object?>>();
        foreach (var e in employees)
        {
            try
            {
                var b = calc.CalculateBalance(e.Id, asOf, true);
                rows.Add(new Dictionary<string, object?> { ["رقم الموظف"] = e.EmployeeNumber,["الاسم"] = e.ArabicName,["الرصيد المرحل"] = b.OpeningBalance,["الاستحقاق"] = b.Accrued,["المستخدم"] = b.Used,["التعديلات"] = b.Adjustments,["الرصيد"] = b.CurrentBalance,["إجازات مستقبلية"] = b.FutureApproved });
            }
            catch { }
        }
        return rows;
    }

    public List<Dictionary<string, object?>> GetEndOfServiceReport()
    {
        var rows = new List<Dictionary<string, object?>>(); var emp = new EmployeeService(); var term = new TerminationService(); var eosb = new EndOfServiceBenefitService();
        foreach (var e in emp.GetAll())
        {
            var t = term.Get(e.Id); if (t is null) continue;
            var r = eosb.Calculate(e, t.LastWorkingDay, t.Reason, false, t.LegalArticle);
            rows.Add(new Dictionary<string, object?> { ["رقم الموظف"] = e.EmployeeNumber,["الاسم"] = e.ArabicName,["آخر يوم عمل"] = t.LastWorkingDay,["السبب"] = t.Reason,["مدة الخدمة"] = r.ServicePeriod.Display,["الأجر المؤهل"] = r.EligibleMonthlyWage,["المكافأة الأساسية"] = r.BasicAward,["نسبة الاستحقاق"] = r.EntitlementRate,["المكافأة النهائية"] = r.FinalAward });
        }
        return rows;
    }


    public List<Dictionary<string, object?>> GetFinalSettlementReport()
    {
        var rows = new List<Dictionary<string, object?>>(); var employees = new EmployeeService(); var termination = new TerminationService(); var settlement = new FinalSettlementService();
        foreach (var e in employees.GetAll())
        {
            if (termination.Get(e.Id) is null) continue;
            try
            {
                var r = settlement.Calculate(e.Id);
                rows.Add(new Dictionary<string, object?> { ["رقم الموظف"] = e.EmployeeNumber,["الاسم"] = e.ArabicName,["نهاية الخدمة"] = r.LastWorkingDay,["مدة الخدمة"] = r.ServicePeriod.Display,["الأجر الشهري الأخير"] = r.LastGrossMonthlyWage,["الراتب المستحق"] = r.SalaryUntilLastDay,["مكافأة نهاية الخدمة"] = r.Eosb,["رصيد الإجازة"] = r.LeaveDays,["قيمة الإجازة"] = r.LeaveValue,["تعويض الإنهاء"] = r.TerminationCompensation,["إجمالي المستحقات"] = r.TotalEntitlements,["إجمالي الخصومات"] = r.TotalDeductions,["صافي التصفية"] = r.NetSettlement });
            }
            catch { }
        }
        return rows;
    }
    public string ExportXlsx(string title, List<Dictionary<string, object?>> rows)
    {
        var path = Path.Combine(AppPaths.ExportsDirectory, $"{Safe(title)}_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx");
        var headers = rows.FirstOrDefault()?.Keys.ToList() ?? new List<string>();
        SimpleXlsxWriter.Write(path, headers, rows.Select(r => headers.Select(h => r.GetValueOrDefault(h))), title.Length > 25 ? title[..25] : title);
        AuditService.Log("تصدير Excel", "Report", "", Path.GetFileName(path)); return path;
    }

    public string ExportPdf(string title, List<Dictionary<string, object?>> rows)
    {
        var pages = BuildTablePages(title, rows).Select(page => PdfImageWriter.Render(page)).ToList();
        var path = Path.Combine(AppPaths.ExportsDirectory, $"{Safe(title)}_{DateTime.Now:yyyyMMdd_HHmmss}.pdf");
        PdfImageWriter.Write(path, pages); AuditService.Log("تصدير PDF", "Report", "", Path.GetFileName(path)); return path;
    }

    public void Print(string title, List<Dictionary<string, object?>> rows)
    {
        var reportPages = BuildTablePages(title, rows); if (reportPages.Count == 0) return;
        var dialog = new PrintDialog(); if (dialog.ShowDialog() != true) return;
        var doc = new FixedDocument();
        foreach (var visual in reportPages)
        {
            var page = new FixedPage { Width = 794, Height = 1123, Background = Brushes.White };
            visual.Width = 794; visual.Height = 1123; page.Children.Add(visual);
            var content = new PageContent(); ((IAddChild)content).AddChild(page); doc.Pages.Add(content);
        }
        dialog.PrintDocument(doc.DocumentPaginator, title);
    }

    public void PrintFinalSettlement(FinalSettlementResult r)
    {
        var visual=BuildSettlementVisual(r); var dialog=new PrintDialog(); if(dialog.ShowDialog()==true) dialog.PrintVisual(visual,"كشف التصفية النهائية");
    }

    public string ExportFinalSettlementPdf(FinalSettlementResult r)
    {
        var visual = BuildSettlementVisual(r);
        var path = Path.Combine(AppPaths.ExportsDirectory, $"تصفية_{Safe(r.Employee.ArabicName)}_{DateTime.Now:yyyyMMdd_HHmmss}.pdf");
        PdfImageWriter.Write(path, new[] { PdfImageWriter.Render(visual) }); AuditService.Log("تصدير كشف تصفية PDF", "FinalSettlement", r.Employee.Id.ToString(), Path.GetFileName(path)); return path;
    }

    public FrameworkElement BuildSettlementVisual(FinalSettlementResult r)
    {
        var root = PageRoot($"كشف التصفية النهائية", $"تاريخ الإعداد: {DateTime.Now:yyyy/MM/dd}");
        var body = (StackPanel)root.Children[2];
        AddKeyValue(body, "اسم الموظف", r.Employee.ArabicName); AddKeyValue(body, "رقم الهوية / الإقامة", r.Employee.NationalId);
        AddKeyValue(body, "تاريخ بداية العمل", r.Employee.StartDate.ToString("yyyy/MM/dd")); AddKeyValue(body, "تاريخ نهاية الخدمة", r.LastWorkingDay.ToString("yyyy/MM/dd"));
        AddKeyValue(body, "مدة الخدمة", r.ServicePeriod.Display); AddKeyValue(body, "الأجر الشهري الإجمالي الأخير", $"{r.LastGrossMonthlyWage:N2} ريال"); AddKeyValue(body, "الأجر المؤهل لمكافأة نهاية الخدمة", $"{r.EosbEligibleMonthlyWage:N2} ريال"); AddKeyValue(body, "رصيد الإجازة", $"{r.LeaveDays:N2} يوم");
        body.Children.Add(Section("المستحقات"));
        AddMoney(body, "الراتب حتى آخر يوم عمل", r.SalaryUntilLastDay); AddMoney(body, "مكافأة نهاية الخدمة", r.Eosb); AddMoney(body, "قيمة رصيد الإجازة", r.LeaveValue); AddMoney(body, "تعويض إنهاء العقد", r.TerminationCompensation); AddMoney(body, "مستحقات أخرى", r.PriorSalaryDue + r.AllowancesDue + r.CommissionsDue + r.ExpensesDue + r.OtherEntitlements); AddMoney(body, "إجمالي المستحقات", r.TotalEntitlements, true);
        body.Children.Add(Section("الخصومات"));
        AddMoney(body, "السلف", r.Advances); AddMoney(body, "القروض", r.Loans); AddMoney(body, "خصومات نظامية/أخرى", r.StatutoryDeductions + r.EmployerReceivables + r.OtherDeductions); AddMoney(body, "إجمالي الخصومات", r.TotalDeductions, true); AddMoney(body, "صافي المستحق", r.NetSettlement, true, 18);
        var sig = new Grid { Margin = new Thickness(10, 30, 10, 0) }; sig.ColumnDefinitions.Add(new ColumnDefinition()); sig.ColumnDefinitions.Add(new ColumnDefinition());
        sig.Children.Add(new TextBlock { Text = "توقيع الموظف: ____________________", FontSize = 14, Margin = new Thickness(10) });
        var boss = new TextBlock { Text = "توقيع المسؤول: ____________________", FontSize = 14, Margin = new Thickness(10) }; Grid.SetColumn(boss, 1); sig.Children.Add(boss); body.Children.Add(sig);
        return root;
    }

    private List<Grid> BuildTablePages(string title, List<Dictionary<string, object?>> rows)
    {
        var headers = rows.FirstOrDefault()?.Keys.ToList() ?? new List<string> { "البيان" };
        const int perPage = 25; var pages = new List<Grid>(); var chunks = rows.Count == 0 ? new[] { new List<Dictionary<string, object?>>() } : rows.Chunk(perPage).Select(x => x.ToList());
        var pageNo = 0; var total = Math.Max(1, (int)Math.Ceiling(rows.Count / (double)perPage));
        foreach (var chunk in chunks)
        {
            pageNo++; var root = PageRoot(title, $"صفحة {pageNo} من {total} - {DateTime.Now:yyyy/MM/dd HH:mm}"); var body = (StackPanel)root.Children[2];
            var table = new Grid { Margin = new Thickness(20, 10, 20, 10) };
            foreach (var _ in headers) table.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            AddTableRow(table, headers.Cast<object?>().ToList(), 0, true);
            var rowIndex = 1; foreach (var row in chunk) AddTableRow(table, headers.Select(h => row.GetValueOrDefault(h)).ToList(), rowIndex++, false);
            body.Children.Add(table); pages.Add(root);
        }
        return pages;
    }

    private Grid PageRoot(string title, string subtitle)
    {
        var root = new Grid { Width = 794, Height = 1123, Background = Brushes.White, FlowDirection = FlowDirection.RightToLeft };
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); root.RowDefinitions.Add(new RowDefinition());
        var t = new TextBlock { Text = title, FontSize = 24, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Color.FromRgb(23, 74, 110)), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(20, 25, 20, 5) }; root.Children.Add(t);
        var s = new TextBlock { Text = subtitle, FontSize = 11, Foreground = Brushes.DimGray, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(5) }; Grid.SetRow(s, 1); root.Children.Add(s);
        var body = new StackPanel { Margin = new Thickness(25, 8, 25, 25) }; Grid.SetRow(body, 2); root.Children.Add(body); return root;
    }

    private static void AddTableRow(Grid table, IList<object?> values, int row, bool header)
    {
        table.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        for (var i = 0; i < values.Count; i++)
        {
            var border = new Border { BorderBrush = Brushes.LightGray, BorderThickness = new Thickness(0.5), Background = header ? new SolidColorBrush(Color.FromRgb(230, 238, 244)) : Brushes.White, Padding = new Thickness(3) };
            border.Child = new TextBlock { Text = Format(values[i]), FontSize = header ? 10 : 9, FontWeight = header ? FontWeights.Bold : FontWeights.Normal, TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center };
            Grid.SetRow(border, row); Grid.SetColumn(border, i); table.Children.Add(border);
        }
    }

    private static TextBlock Section(string text) => new() { Text = text, FontSize = 16, FontWeight = FontWeights.Bold, Margin = new Thickness(0, 12, 0, 4), Foreground = new SolidColorBrush(Color.FromRgb(23, 74, 110)) };
    private static void AddKeyValue(Panel p, string key, string value) { var g = new Grid { Margin = new Thickness(4) }; g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(180) }); g.ColumnDefinitions.Add(new ColumnDefinition()); g.Children.Add(new TextBlock { Text = key, FontWeight = FontWeights.Bold, FontSize = 13 }); var v = new TextBlock { Text = value, FontSize = 13 }; Grid.SetColumn(v, 1); g.Children.Add(v); p.Children.Add(g); }
    private static void AddMoney(Panel p, string key, decimal value, bool bold = false, int size = 13) { var g = new Grid { Margin = new Thickness(4) }; g.ColumnDefinitions.Add(new ColumnDefinition()); g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(180) }); g.Children.Add(new TextBlock { Text = key, FontWeight = bold ? FontWeights.Bold : FontWeights.Normal, FontSize = size }); var v = new TextBlock { Text = $"{value:N2} ريال", FontWeight = bold ? FontWeights.Bold : FontWeights.Normal, FontSize = size, TextAlignment = TextAlignment.Left }; Grid.SetColumn(v, 1); g.Children.Add(v); p.Children.Add(g); }
    private static string Format(object? v) => v switch { null => "", DateTime d => d.ToString("yyyy/MM/dd"), decimal m => m.ToString("N2"), double d => d.ToString("N2"), _ => Convert.ToString(v) ?? "" };
    private static string Safe(string s) => string.Concat(s.Select(ch => Path.GetInvalidFileNameChars().Contains(ch) ? '_' : ch));
}
