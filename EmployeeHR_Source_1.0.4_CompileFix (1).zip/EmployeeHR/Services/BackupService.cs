using EmployeeHR.Utilities;

namespace EmployeeHR.Services;

public static class BackupService
{
    public static string CreateBackup(string reason="manual",bool silent=false)
    {
        AppPaths.EnsureWritableStructure();
        if (!File.Exists(AppPaths.DatabasePath)) return "";
        var safeReason = new string(reason.Where(char.IsLetterOrDigit).ToArray());
        if (string.IsNullOrEmpty(safeReason)) safeReason="backup";
        var file=Path.Combine(AppPaths.BackupsDirectory,$"EmployeeHR_{DateTime.Now:yyyyMMdd_HHmmss}_{safeReason}.db");
        File.Copy(AppPaths.DatabasePath,file,true);
        CleanupOldBackups();
        if(!silent) AuditService.Log("إنشاء نسخة احتياطية","Database","",Path.GetFileName(file));
        return file;
    }

    public static void RestoreBackup(string backupPath)
    {
        if(!File.Exists(backupPath)) throw new FileNotFoundException("ملف النسخة الاحتياطية غير موجود.",backupPath);
        CreateBackup("before_restore",true);
        File.Copy(backupPath,AppPaths.DatabasePath,true);
        AuditService.Log("استعادة نسخة احتياطية","Database","",Path.GetFileName(backupPath));
    }

    private static void CleanupOldBackups()
    {
        var keep=SettingsService.GetInt("BackupRetention",30);
        var files=new DirectoryInfo(AppPaths.BackupsDirectory).GetFiles("EmployeeHR_*.db").OrderByDescending(f=>f.CreationTimeUtc).ToList();
        foreach(var f in files.Skip(Math.Max(keep,5))) { try{f.Delete();}catch{} }
    }
}
