using EmployeeHR.Models;
using EmployeeHR.Repositories;

namespace EmployeeHR.Services;

public sealed class ContractService
{
    private readonly ContractRepository _repo=new();
    public List<ContractRecord> GetHistory(long employeeId)=>_repo.GetByEmployee(employeeId);
    public long Add(ContractRecord c)
    {
        if(c.EmployeeId<=0) throw new InvalidOperationException("اختر الموظف.");
        if(c.EndDate.HasValue && c.EndDate<c.StartDate) throw new InvalidOperationException("تاريخ نهاية العقد يجب ألا يسبق البداية.");
        var id=_repo.Add(c); AuditService.Log("إضافة/تحديث عقد","Contract",id.ToString(),$"موظف {c.EmployeeId} - {c.ContractType}"); return id;
    }
}
