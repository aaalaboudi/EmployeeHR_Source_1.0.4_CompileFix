using EmployeeHR.Data;

namespace EmployeeHR.Services;

public static class SettingsService
{
    public static string Get(string key,string fallback="")
    {
        using var db=Db.Open();
        var v = Db.S(db.Scalar("SELECT Value FROM Settings WHERE Key=@k;",new Dictionary<string,object?>{{"k",key}}));
        return string.IsNullOrEmpty(v) ? fallback : v;
    }
    public static int GetInt(string key,int fallback){return int.TryParse(Get(key),out var v)?v:fallback;}
    public static decimal GetDecimal(string key,decimal fallback){return decimal.TryParse(Get(key),out var v)?v:fallback;}
    public static void Set(string key,string value)
    {
        using var db=Db.Open();
        db.Execute("INSERT OR REPLACE INTO Settings(Key,Value,UpdatedAt) VALUES(@k,@v,@u);",new Dictionary<string,object?>{{"k",key},{"v",value},{"u",DateTime.Now.ToString("s")}});
    }
}
