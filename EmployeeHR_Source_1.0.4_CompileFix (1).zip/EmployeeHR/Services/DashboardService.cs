using EmployeeHR.Calculation;
using EmployeeHR.Data;
using EmployeeHR.Models;
using EmployeeHR.Repositories;

namespace EmployeeHR.Services;

public sealed class DashboardService
{
    private readonly EmployeeRepository _employees = new();
    private readonly LeaveCalculationService _leave = new();
    private readonly LeaveRepository _leaveRepo = new();
    public DashboardMetrics GetMetrics(DateTime? date = null)
    {
        var today = (date ?? DateTime.Today).Date;
        var all = _employees.GetAll();
        var active = all.Where(x => x.Status == "على رأس العمل").ToList();
        var warning = SettingsService.GetInt("ExpiryWarningDays", 60);
        decimal totalBalance = 0; var high = 0; var threshold = SettingsService.GetDecimal("HighLeaveBalanceThreshold", 45);
        foreach (var e in active)
        {
            try { var b = _leave.CalculateBalance(e.Id, today, true).CurrentBalance; totalBalance += b; if (b >= threshold) high++; } catch { }
        }
        using var db = Db.Open();
        var currentLeaves = Convert.ToInt32(db.Scalar("SELECT COUNT(*) FROM LeaveRequests WHERE Status='معتمدة' AND StartDate<=@d AND EndDate>=@d;", new Dictionary<string, object?> { ["d"] = today }) ?? 0);
        var upcomingLeaves = Convert.ToInt32(db.Scalar("SELECT COUNT(*) FROM LeaveRequests WHERE Status='معتمدة' AND StartDate>@d AND StartDate<=date(@d,'+30 day');", new Dictionary<string, object?> { ["d"] = today }) ?? 0);
        return new DashboardMetrics
        {
            TotalEmployees = all.Count, ActiveEmployees = active.Count, TerminatedEmployees = all.Count - active.Count,
            ContractsExpiringSoon = active.Count(x => x.ContractEnd.HasValue && x.ContractEnd.Value.Date >= today && x.ContractEnd.Value.Date <= today.AddDays(warning)),
            IqamasExpiringSoon = active.Count(x => x.IqamaExpiry.HasValue && x.IqamaExpiry.Value.Date >= today && x.IqamaExpiry.Value.Date <= today.AddDays(warning)),
            CurrentLeaves = currentLeaves, UpcomingLeaves = upcomingLeaves, TotalLeaveBalances = Math.Round(totalBalance, 2), HighLeaveBalanceEmployees = high,
            ApproachingFiveYears = active.Count(x => { var five = ProjectedFiveYearDate(x); return five >= today && five <= today.AddDays(90); })
        };
    }

    private DateTime ProjectedFiveYearDate(Employee employee)
    {
        var requiredNetDays = (employee.StartDate.Date.AddYears(5) - employee.StartDate.Date).Days;
        var excluded = _leaveRepo.GetUnpaid(employee.Id).Where(x => x.AffectsService).ToList();
        var netDays = 0;
        for (var d = employee.StartDate.Date; ; d = d.AddDays(1))
        {
            var isExcluded = excluded.Any(x => d >= x.StartDate.Date && d <= x.EndDate.Date);
            if (!isExcluded) netDays++;
            if (netDays > requiredNetDays) return d; // first day after five completed net service years
        }
    }
}
