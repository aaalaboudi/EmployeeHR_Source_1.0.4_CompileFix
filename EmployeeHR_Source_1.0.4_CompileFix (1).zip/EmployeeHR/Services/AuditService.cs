using EmployeeHR.Data;

namespace EmployeeHR.Services;

public static class AuditService
{
    public static void Log(string action,string entityType,string entityId="",string details="")
    {
        try
        {
            using var db=Db.Open();
            db.Execute(@"INSERT INTO AuditLog(EventAt,Action,EntityType,EntityId,Details,WindowsUser,MachineName) VALUES(@d,@a,@t,@i,@x,@u,@m);",new Dictionary<string,object?>{
                ["d"]=DateTime.Now.ToString("s"),["a"]=action,["t"]=entityType,["i"]=entityId,["x"]=details,["u"]=Environment.UserName,["m"]=Environment.MachineName
            });
        }
        catch { }
    }

    public static List<Dictionary<string,object?>> GetRecent(int limit=1000)
    {
        using var db=Db.Open();
        return db.Query($"SELECT EventAt 'التاريخ والوقت',Action 'الإجراء',EntityType 'النوع',EntityId 'المعرف',Details 'التفاصيل',WindowsUser 'المستخدم',MachineName 'الجهاز' FROM AuditLog ORDER BY Id DESC LIMIT {Math.Clamp(limit,1,5000)};");
    }
}
