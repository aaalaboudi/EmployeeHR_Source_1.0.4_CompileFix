using EmployeeHR.Data;
using EmployeeHR.Models;
using EmployeeHR.Repositories;

namespace EmployeeHR.Services;

public sealed class TerminationService
{
    private readonly EmployeeRepository _employees = new();
    private readonly RulesRepository _rules = new();

    public List<TerminationReason> GetReasons() => _rules.GetTerminationReasons();

    public TerminationRecord? Get(long employeeId)
    {
        using var db = Db.Open();
        var r = db.Query("SELECT * FROM Terminations WHERE EmployeeId=@e LIMIT 1;", new Dictionary<string, object?> { ["e"] = employeeId }).FirstOrDefault();
        if (r is null) return null;
        return new TerminationRecord
        {
            Id = Db.L(r["Id"]), EmployeeId = Db.L(r["EmployeeId"]), LastWorkingDay = Db.Date(r["LastWorkingDay"]), Reason = Db.S(r["Reason"]),
            InitiatedBy = Db.S(r["InitiatedBy"]), LegalArticle = Db.S(r["LegalArticle"]), Notes = Db.S(r["Notes"]),
            HasContractCompensationClause = Db.B(r["HasContractCompensationClause"]), CompensationMethod = Db.S(r["CompensationMethod"]), CompensationAmount = Db.D(r["CompensationAmount"])
        };
    }

    public long Save(TerminationRecord t)
    {
        var employee = _employees.Get(t.EmployeeId) ?? throw new InvalidOperationException("الموظف غير موجود.");
        if (t.LastWorkingDay.Date < employee.StartDate.Date) throw new InvalidOperationException("آخر يوم عمل يسبق بداية الخدمة.");
        using var db = Db.Open();
        db.Begin();
        try
        {
            var existing = db.Scalar("SELECT Id FROM Terminations WHERE EmployeeId=@e;", new Dictionary<string, object?> { ["e"] = t.EmployeeId });
            long id;
            var p = new Dictionary<string, object?>
            {
                ["e"] = t.EmployeeId,["d"] = t.LastWorkingDay,["r"] = t.Reason,["b"] = t.InitiatedBy,["a"] = t.LegalArticle,["n"] = t.Notes,
                ["h"] = t.HasContractCompensationClause,["m"] = t.CompensationMethod,["c"] = t.CompensationAmount,["now"] = DateTime.Now.ToString("s")
            };
            if (existing is null)
                id = db.ExecuteInsert(@"INSERT INTO Terminations(EmployeeId,LastWorkingDay,Reason,InitiatedBy,LegalArticle,Notes,HasContractCompensationClause,CompensationMethod,CompensationAmount,CreatedAt) VALUES(@e,@d,@r,@b,@a,@n,@h,@m,@c,@now);", p);
            else
            {
                id = Convert.ToInt64(existing); p["id"] = id;
                db.Execute(@"UPDATE Terminations SET LastWorkingDay=@d,Reason=@r,InitiatedBy=@b,LegalArticle=@a,Notes=@n,HasContractCompensationClause=@h,CompensationMethod=@m,CompensationAmount=@c WHERE Id=@id;", p);
            }
            db.Execute("UPDATE Employees SET Status='منتهية خدمته',UpdatedAt=@u WHERE Id=@e;", new Dictionary<string, object?> { ["u"] = DateTime.Now.ToString("s"),["e"] = t.EmployeeId });
            db.Commit();
            AuditService.Log("حفظ إنهاء خدمة", "Termination", id.ToString(), $"{employee.ArabicName} - {t.Reason} - {t.LastWorkingDay:yyyy/MM/dd}");
            return id;
        }
        catch { db.Rollback(); throw; }
    }
}
