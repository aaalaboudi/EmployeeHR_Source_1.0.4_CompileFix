using EmployeeHR.Calculation;
using EmployeeHR.Models;
using EmployeeHR.Repositories;

namespace EmployeeHR.Services;

public sealed class LeaveService
{
    private readonly LeaveRepository _repo = new();
    private readonly LeaveCalculationService _calc = new();
    public List<LeaveRequest> GetAll() => _repo.GetAll();
    public List<UnpaidLeave> GetUnpaid(long? employeeId = null) => _repo.GetUnpaid(employeeId);
    public int CountDays(DateTime start, DateTime end) => _calc.CountLeaveDays(start, end);
    public long Add(LeaveRequest l)
    {
        if (l.EmployeeId <= 0) throw new InvalidOperationException("اختر الموظف.");
        l.DaysCount = _calc.CountLeaveDays(l.StartDate, l.EndDate);
        var id = _repo.AddLeave(l); AuditService.Log("إضافة إجازة", "LeaveRequest", id.ToString(), $"{l.StartDate:yyyy/MM/dd}-{l.EndDate:yyyy/MM/dd}، {l.DaysCount} يوم، {l.Status}"); return id;
    }
    public void SetStatus(long id, string status) { _repo.UpdateLeaveStatus(id, status); AuditService.Log("تغيير حالة إجازة", "LeaveRequest", id.ToString(), status); }
    public long AddUnpaid(UnpaidLeave u)
    {
        if (u.EmployeeId <= 0) throw new InvalidOperationException("اختر الموظف.");
        if (u.EndDate.Date < u.StartDate.Date) throw new InvalidOperationException("تاريخ نهاية الإجازة يسبق البداية.");
        u.DaysCount = (u.EndDate.Date - u.StartDate.Date).Days + 1;
        var id = _repo.AddUnpaid(u); AuditService.Log("إضافة إجازة بدون أجر", "UnpaidLeave", id.ToString(), $"{u.DaysCount} يوم؛ تؤثر على الخدمة={u.AffectsService}؛ الاستحقاق={u.AffectsLeaveAccrual}؛ العقد موقوف={u.ContractSuspended}"); return id;
    }
}
