using EmployeeHR.Data;
using EmployeeHR.Models;

namespace EmployeeHR.Repositories;

public sealed class ContractRepository
{
    public List<ContractRecord> GetByEmployee(long employeeId)
    {
        using var db = Db.Open();
        return db.Query("SELECT * FROM Contracts WHERE EmployeeId=@e ORDER BY EffectiveFrom DESC;", new Dictionary<string, object?> { ["e"] = employeeId }).Select(Map).ToList();
    }

    public long Add(ContractRecord c)
    {
        using var db = Db.Open();
        db.Begin();
        try
        {
            if (c.EndDate.HasValue && c.EndDate.Value.Date < c.StartDate.Date) throw new InvalidOperationException("تاريخ نهاية العقد يسبق تاريخ بدايته.");
            if (c.EffectiveTo.HasValue && c.EffectiveTo.Value.Date < c.EffectiveFrom.Date) throw new InvalidOperationException("تاريخ السريان إلى يسبق تاريخ السريان من.");
            var duplicate = Convert.ToInt32(db.Scalar("SELECT COUNT(*) FROM Contracts WHERE EmployeeId=@e AND EffectiveFrom=@d;", new Dictionary<string, object?> { ["e"] = c.EmployeeId, ["d"] = c.EffectiveFrom }) ?? 0);
            if (duplicate > 0) throw new InvalidOperationException("يوجد سجل عقد يبدأ في تاريخ السريان نفسه لهذا الموظف.");

            var nextValue = db.Scalar("SELECT MIN(EffectiveFrom) FROM Contracts WHERE EmployeeId=@e AND EffectiveFrom>@d;", new Dictionary<string, object?> { ["e"] = c.EmployeeId, ["d"] = c.EffectiveFrom });
            var nextStart = Db.DateN(nextValue);
            var effectiveTo = c.EffectiveTo;
            if (nextStart.HasValue)
            {
                var latestAllowed = nextStart.Value.AddDays(-1);
                if (effectiveTo.HasValue && effectiveTo.Value.Date > latestAllowed.Date) throw new InvalidOperationException("فترة سريان العقد تتداخل مع سجل لاحق.");
                effectiveTo ??= latestAllowed;
            }

            db.Execute("UPDATE Contracts SET EffectiveTo=date(@d,'-1 day') WHERE EmployeeId=@e AND EffectiveFrom<@d AND (EffectiveTo IS NULL OR EffectiveTo>=@d);", new Dictionary<string, object?> { ["d"] = c.EffectiveFrom, ["e"] = c.EmployeeId });
            var id = db.ExecuteInsert(@"INSERT INTO Contracts(EmployeeId,ContractType,StartDate,EndDate,ProbationDays,EffectiveFrom,EffectiveTo,Notes) VALUES(@e,@t,@s,@end,@p,@ef,@et,@n);", new Dictionary<string, object?> {
                ["e"] = c.EmployeeId,["t"] = c.ContractType,["s"] = c.StartDate,["end"] = c.EndDate,["p"] = c.ProbationDays,["ef"] = c.EffectiveFrom,["et"] = effectiveTo,["n"] = c.Notes
            });
            // The employee summary always reflects the chronologically latest contract record.
            var latestId = Convert.ToInt64(db.Scalar("SELECT Id FROM Contracts WHERE EmployeeId=@e ORDER BY EffectiveFrom DESC,Id DESC LIMIT 1;", new Dictionary<string, object?> { ["e"] = c.EmployeeId }) ?? id);
            if (latestId == id)
                db.Execute("UPDATE Employees SET ContractType=@t,ContractStart=@s,ContractEnd=@end,ProbationDays=@p,UpdatedAt=@u WHERE Id=@e;", new Dictionary<string, object?> { ["t"] = c.ContractType,["s"] = c.StartDate,["end"] = c.EndDate,["p"] = c.ProbationDays,["u"] = DateTime.Now.ToString("s"),["e"] = c.EmployeeId });
            db.Commit(); return id;
        }
        catch { db.Rollback(); throw; }
    }

    private static ContractRecord Map(Dictionary<string, object?> r) => new() { Id=Db.L(r["Id"]),EmployeeId=Db.L(r["EmployeeId"]),ContractType=Db.S(r["ContractType"]),StartDate=Db.Date(r["StartDate"]),EndDate=Db.DateN(r["EndDate"]),ProbationDays=Db.I(r["ProbationDays"]),EffectiveFrom=Db.Date(r["EffectiveFrom"]),EffectiveTo=Db.DateN(r["EffectiveTo"]),Notes=Db.S(r["Notes"]) };
}
