using EmployeeHR.Data;
using EmployeeHR.Models;

namespace EmployeeHR.Repositories;

public sealed class LeaveRepository
{
    public List<LeaveRequest> GetAll()
    {
        using var db = Db.Open();
        return db.Query(@"SELECT l.*,e.ArabicName EmployeeName FROM LeaveRequests l JOIN Employees e ON e.Id=l.EmployeeId ORDER BY l.StartDate DESC;").Select(MapLeave).ToList();
    }
    public List<LeaveRequest> GetByEmployee(long employeeId)
    {
        using var db=Db.Open(); return db.Query(@"SELECT l.*,e.ArabicName EmployeeName FROM LeaveRequests l JOIN Employees e ON e.Id=l.EmployeeId WHERE l.EmployeeId=@e ORDER BY l.StartDate DESC;", new Dictionary<string, object?> { ["e"] = employeeId }).Select(MapLeave).ToList();
    }
    public long AddLeave(LeaveRequest l)
    {
        using var db=Db.Open(); var now=DateTime.Now.ToString("s");
        return db.ExecuteInsert(@"INSERT INTO LeaveRequests(EmployeeId,StartDate,EndDate,DaysCount,LeaveType,Status,Notes,CreatedAt,UpdatedAt) VALUES(@e,@s,@end,@d,@t,@st,@n,@c,@c);", new Dictionary<string, object?> { ["e"]=l.EmployeeId,["s"]=l.StartDate,["end"]=l.EndDate,["d"]=l.DaysCount,["t"]=l.LeaveType,["st"]=l.Status,["n"]=l.Notes,["c"]=now });
    }
    public void UpdateLeaveStatus(long id,string status) { using var db=Db.Open(); db.Execute("UPDATE LeaveRequests SET Status=@s,UpdatedAt=@u WHERE Id=@id;", new Dictionary<string, object?> { ["s"]=status,["u"]=DateTime.Now.ToString("s"),["id"]=id }); }

    public List<UnpaidLeave> GetUnpaid(long? employeeId=null)
    {
        using var db=Db.Open();
        var sql=@"SELECT u.*,e.ArabicName EmployeeName FROM UnpaidLeaves u JOIN Employees e ON e.Id=u.EmployeeId" + (employeeId.HasValue ? " WHERE u.EmployeeId=@e" : "") + " ORDER BY u.StartDate DESC;";
        return db.Query(sql, employeeId.HasValue ? new Dictionary<string, object?> { ["e"]=employeeId.Value } : null).Select(MapUnpaid).ToList();
    }
    public long AddUnpaid(UnpaidLeave u)
    {
        using var db=Db.Open(); return db.ExecuteInsert(@"INSERT INTO UnpaidLeaves(EmployeeId,StartDate,EndDate,DaysCount,Reason,Notes,AffectsService,AffectsLeaveAccrual,ContractSuspended,CreatedAt) VALUES(@e,@s,@end,@d,@r,@n,@as,@al,@cs,@c);", new Dictionary<string, object?> { ["e"]=u.EmployeeId,["s"]=u.StartDate,["end"]=u.EndDate,["d"]=u.DaysCount,["r"]=u.Reason,["n"]=u.Notes,["as"]=u.AffectsService,["al"]=u.AffectsLeaveAccrual,["cs"]=u.ContractSuspended,["c"]=DateTime.Now.ToString("s") });
    }

    public List<LeaveLedgerEntry> GetLedger(long employeeId, DateTime asOf)
    {
        using var db=Db.Open(); var rows=db.Query("SELECT * FROM LeaveLedger WHERE EmployeeId=@e AND EntryDate<=@d ORDER BY EntryDate,Id;", new Dictionary<string, object?> { ["e"]=employeeId,["d"]=asOf });
        decimal balance=0; var list=new List<LeaveLedgerEntry>();
        foreach(var r in rows) { var x=new LeaveLedgerEntry { Id=Db.L(r["Id"]),EmployeeId=Db.L(r["EmployeeId"]),EntryDate=Db.Date(r["EntryDate"]),EntryType=Db.S(r["EntryType"]),Description=Db.S(r["Description"]),Accrued=Db.D(r["Accrued"]),Used=Db.D(r["Used"]),Adjustment=Db.D(r["Adjustment"]),SystemGenerated=Db.B(r["SystemGenerated"]),SourceId=r["SourceId"] is null?null:Db.L(r["SourceId"]) }; balance += x.Accrued + x.Adjustment - x.Used; x.RunningBalance=balance; list.Add(x); }
        return list;
    }

    public void ReplaceSystemLedger(long employeeId,IEnumerable<LeaveLedgerEntry> entries)
    {
        using var db=Db.Open(); db.Begin();
        try
        {
            db.Execute("DELETE FROM LeaveLedger WHERE EmployeeId=@e AND SystemGenerated=1;", new Dictionary<string, object?> { ["e"]=employeeId });
            foreach(var x in entries) db.Execute(@"INSERT INTO LeaveLedger(EmployeeId,EntryDate,EntryType,Description,Accrued,Used,Adjustment,SystemGenerated,SourceId,CreatedAt) VALUES(@e,@d,@t,@desc,@a,@u,@adj,1,@src,@c);", new Dictionary<string, object?> { ["e"]=employeeId,["d"]=x.EntryDate,["t"]=x.EntryType,["desc"]=x.Description,["a"]=x.Accrued,["u"]=x.Used,["adj"]=x.Adjustment,["src"]=x.SourceId,["c"]=DateTime.Now.ToString("s") });
            db.Commit();
        }
        catch { db.Rollback(); throw; }
    }

    public void AddAdjustment(long employeeId,DateTime date,decimal amount,string description)
    {
        using var db=Db.Open(); db.Execute(@"INSERT INTO LeaveLedger(EmployeeId,EntryDate,EntryType,Description,Accrued,Used,Adjustment,SystemGenerated,CreatedAt) VALUES(@e,@d,'تعديل يدوي',@desc,0,0,@a,0,@c);",new Dictionary<string, object?> { ["e"]=employeeId,["d"]=date,["desc"]=description,["a"]=amount,["c"]=DateTime.Now.ToString("s") });
    }

    public void SetOpeningBalance(long employeeId,DateTime date,decimal amount,string description)
    {
        using var db=Db.Open(); db.Begin();
        try
        {
            db.Execute("DELETE FROM LeaveLedger WHERE EmployeeId=@e AND SystemGenerated=0 AND EntryType='رصيد افتتاحي';",new Dictionary<string,object?>{{"e",employeeId}});
            db.Execute(@"INSERT INTO LeaveLedger(EmployeeId,EntryDate,EntryType,Description,Accrued,Used,Adjustment,SystemGenerated,CreatedAt) VALUES(@e,@d,'رصيد افتتاحي',@desc,0,0,@a,0,@c);",new Dictionary<string,object?>{{"e",employeeId},{"d",date},{"desc",description},{"a",amount},{"c",DateTime.Now.ToString("s")}});
            db.Commit();
        }
        catch { db.Rollback(); throw; }
    }

    private static LeaveRequest MapLeave(Dictionary<string, object?> r)=>new(){Id=Db.L(r["Id"]),EmployeeId=Db.L(r["EmployeeId"]),EmployeeName=Db.S(r["EmployeeName"]),StartDate=Db.Date(r["StartDate"]),EndDate=Db.Date(r["EndDate"]),DaysCount=Db.D(r["DaysCount"]),LeaveType=Db.S(r["LeaveType"]),Status=Db.S(r["Status"]),Notes=Db.S(r["Notes"])};
    private static UnpaidLeave MapUnpaid(Dictionary<string, object?> r)=>new(){Id=Db.L(r["Id"]),EmployeeId=Db.L(r["EmployeeId"]),EmployeeName=Db.S(r["EmployeeName"]),StartDate=Db.Date(r["StartDate"]),EndDate=Db.Date(r["EndDate"]),DaysCount=Db.I(r["DaysCount"]),Reason=Db.S(r["Reason"]),Notes=Db.S(r["Notes"]),AffectsService=Db.B(r["AffectsService"]),AffectsLeaveAccrual=Db.B(r["AffectsLeaveAccrual"]),ContractSuspended=Db.B(r["ContractSuspended"])};
}
