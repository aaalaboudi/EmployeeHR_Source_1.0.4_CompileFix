using EmployeeHR.Data;
using EmployeeHR.Models;

namespace EmployeeHR.Repositories;

public sealed class SalaryRepository
{
    public SalaryRecord? GetAt(long employeeId, DateTime date)
    {
        using var db = Db.Open();
        var r = db.Query(@"SELECT * FROM SalaryHistory WHERE EmployeeId=@e AND EffectiveFrom<=@d AND (EffectiveTo IS NULL OR EffectiveTo>=@d) ORDER BY EffectiveFrom DESC LIMIT 1;", new Dictionary<string, object?> { ["e"] = employeeId, ["d"] = date }).FirstOrDefault();
        return r is null ? null : Map(r);
    }

    public List<SalaryRecord> GetHistory(long employeeId)
    {
        using var db = Db.Open();
        return db.Query("SELECT * FROM SalaryHistory WHERE EmployeeId=@e ORDER BY EffectiveFrom DESC;", new Dictionary<string, object?> { ["e"] = employeeId }).Select(Map).ToList();
    }

    public long Add(SalaryRecord s)
    {
        using var db = Db.Open(); db.Begin();
        try
        {
            var duplicate = Convert.ToInt32(db.Scalar("SELECT COUNT(*) FROM SalaryHistory WHERE EmployeeId=@e AND EffectiveFrom=@d;", new Dictionary<string, object?> { ["e"] = s.EmployeeId, ["d"] = s.EffectiveFrom }) ?? 0);
            if (duplicate > 0) throw new InvalidOperationException("يوجد سجل راتب يبدأ في التاريخ نفسه لهذا الموظف.");

            var nextValue = db.Scalar("SELECT MIN(EffectiveFrom) FROM SalaryHistory WHERE EmployeeId=@e AND EffectiveFrom>@d;", new Dictionary<string, object?> { ["e"] = s.EmployeeId, ["d"] = s.EffectiveFrom });
            var nextStart = Db.DateN(nextValue);
            var effectiveTo = s.EffectiveTo;
            if (effectiveTo.HasValue && effectiveTo.Value.Date < s.EffectiveFrom.Date) throw new InvalidOperationException("تاريخ سريان الراتب إلى يسبق تاريخ السريان من.");
            if (nextStart.HasValue)
            {
                var latestAllowed = nextStart.Value.AddDays(-1);
                if (effectiveTo.HasValue && effectiveTo.Value.Date > latestAllowed.Date) throw new InvalidOperationException("فترة الراتب تتداخل مع سجل راتب لاحق.");
                effectiveTo ??= latestAllowed;
            }

            db.Execute("UPDATE SalaryHistory SET EffectiveTo=date(@d,'-1 day') WHERE EmployeeId=@e AND EffectiveFrom<@d AND (EffectiveTo IS NULL OR EffectiveTo>=@d);", new Dictionary<string, object?> { ["d"] = s.EffectiveFrom, ["e"] = s.EmployeeId });
            var id = db.ExecuteInsert(@"INSERT INTO SalaryHistory(EmployeeId,EffectiveFrom,EffectiveTo,BasicSalary,HousingAllowance,TransportationAllowance,FoodAllowance,OtherFixedAllowances,Commissions,VariableAllowances,CreatedAt) VALUES(@e,@f,@t,@b,@h,@tr,@food,@o,@c,@v,@created);", new Dictionary<string, object?> {
                ["e"] = s.EmployeeId,["f"] = s.EffectiveFrom,["t"] = effectiveTo,["b"] = s.BasicSalary,["h"] = s.HousingAllowance,["tr"] = s.TransportationAllowance,["food"] = s.FoodAllowance,["o"] = s.OtherFixedAllowances,["c"] = s.Commissions,["v"] = s.VariableAllowances,["created"] = DateTime.Now.ToString("s")
            });
            db.Commit(); return id;
        }
        catch { db.Rollback(); throw; }
    }

    public List<SalaryComponentDefinition> GetComponents()
    {
        using var db = Db.Open();
        return db.Query("SELECT * FROM SalaryComponents ORDER BY rowid;").Select(r => new SalaryComponentDefinition { Code=Db.S(r["Code"]),ArabicName=Db.S(r["ArabicName"]),IncludeInEosb=Db.B(r["IncludeInEosb"]),IncludeInLeave=Db.B(r["IncludeInLeave"]),IncludeInOther=Db.B(r["IncludeInOther"]) }).ToList();
    }

    public void UpdateComponent(SalaryComponentDefinition c)
    {
        using var db = Db.Open();
        db.Execute("UPDATE SalaryComponents SET IncludeInEosb=@e,IncludeInLeave=@l,IncludeInOther=@o WHERE Code=@c;", new Dictionary<string, object?> { ["e"] = c.IncludeInEosb,["l"] = c.IncludeInLeave,["o"] = c.IncludeInOther,["c"] = c.Code });
    }

    private static SalaryRecord Map(Dictionary<string, object?> r) => new() { Id=Db.L(r["Id"]),EmployeeId=Db.L(r["EmployeeId"]),EffectiveFrom=Db.Date(r["EffectiveFrom"]),EffectiveTo=Db.DateN(r["EffectiveTo"]),BasicSalary=Db.D(r["BasicSalary"]),HousingAllowance=Db.D(r["HousingAllowance"]),TransportationAllowance=Db.D(r["TransportationAllowance"]),FoodAllowance=Db.D(r["FoodAllowance"]),OtherFixedAllowances=Db.D(r["OtherFixedAllowances"]),Commissions=Db.D(r["Commissions"]),VariableAllowances=Db.D(r["VariableAllowances"]) };
}
