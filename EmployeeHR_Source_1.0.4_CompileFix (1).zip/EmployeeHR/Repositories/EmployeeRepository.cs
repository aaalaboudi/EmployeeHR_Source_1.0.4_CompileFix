using EmployeeHR.Data;
using EmployeeHR.Models;

namespace EmployeeHR.Repositories;

public sealed class EmployeeRepository
{
    public List<Employee> GetAll()
    {
        using var db = Db.Open();
        return db.Query("SELECT * FROM Employees ORDER BY ArabicName;").Select(Map).ToList();
    }

    public List<Employee> GetActive()
    {
        using var db = Db.Open();
        return db.Query("SELECT * FROM Employees WHERE Status='على رأس العمل' ORDER BY ArabicName;").Select(Map).ToList();
    }

    public Employee? Get(long id)
    {
        using var db = Db.Open();
        var row = db.Query("SELECT * FROM Employees WHERE Id=@id;", new Dictionary<string, object?> { ["id"] = id }).FirstOrDefault();
        return row is null ? null : Map(row);
    }

    public long Save(Employee e)
    {
        using var db = Db.Open();
        var p = Params(e);
        if (e.Id == 0)
        {
            p["now"] = DateTime.Now.ToString("s");
            return db.ExecuteInsert(@"INSERT INTO Employees(EmployeeNumber,ArabicName,EnglishName,Nationality,NationalId,IqamaExpiry,BirthDate,Mobile,JobTitle,Department,StartDate,Status,ContractType,ContractStart,ContractEnd,ProbationDays,Notes,CreatedAt,UpdatedAt)
VALUES(@EmployeeNumber,@ArabicName,@EnglishName,@Nationality,@NationalId,@IqamaExpiry,@BirthDate,@Mobile,@JobTitle,@Department,@StartDate,@Status,@ContractType,@ContractStart,@ContractEnd,@ProbationDays,@Notes,@now,@now);", p);
        }
        p["Id"] = e.Id;
        p["now"] = DateTime.Now.ToString("s");
        db.Execute(@"UPDATE Employees SET EmployeeNumber=@EmployeeNumber,ArabicName=@ArabicName,EnglishName=@EnglishName,Nationality=@Nationality,NationalId=@NationalId,IqamaExpiry=@IqamaExpiry,BirthDate=@BirthDate,Mobile=@Mobile,JobTitle=@JobTitle,Department=@Department,StartDate=@StartDate,Status=@Status,ContractType=@ContractType,ContractStart=@ContractStart,ContractEnd=@ContractEnd,ProbationDays=@ProbationDays,Notes=@Notes,UpdatedAt=@now WHERE Id=@Id;", p);
        return e.Id;
    }

    public void SetTerminated(long id, DateTime date)
    {
        using var db = Db.Open();
        db.Execute("UPDATE Employees SET Status='منتهية خدمته', UpdatedAt=@u WHERE Id=@id;", new Dictionary<string, object?> { ["u"] = DateTime.Now.ToString("s"), ["id"] = id });
    }

    private static Dictionary<string, object?> Params(Employee e) => new()
    {
        ["EmployeeNumber"] = e.EmployeeNumber.Trim(), ["ArabicName"] = e.ArabicName.Trim(), ["EnglishName"] = e.EnglishName.Trim(),
        ["Nationality"] = e.Nationality.Trim(), ["NationalId"] = e.NationalId.Trim(), ["IqamaExpiry"] = e.IqamaExpiry, ["BirthDate"] = e.BirthDate,
        ["Mobile"] = e.Mobile.Trim(), ["JobTitle"] = e.JobTitle.Trim(), ["Department"] = e.Department.Trim(), ["StartDate"] = e.StartDate,
        ["Status"] = e.Status, ["ContractType"] = e.ContractType, ["ContractStart"] = e.ContractStart, ["ContractEnd"] = e.ContractEnd,
        ["ProbationDays"] = e.ProbationDays, ["Notes"] = e.Notes.Trim()
    };

    private static Employee Map(Dictionary<string, object?> r) => new()
    {
        Id = Db.L(r["Id"]), EmployeeNumber = Db.S(r["EmployeeNumber"]), ArabicName = Db.S(r["ArabicName"]), EnglishName = Db.S(r["EnglishName"]),
        Nationality = Db.S(r["Nationality"]), NationalId = Db.S(r["NationalId"]), IqamaExpiry = Db.DateN(r["IqamaExpiry"]), BirthDate = Db.DateN(r["BirthDate"]),
        Mobile = Db.S(r["Mobile"]), JobTitle = Db.S(r["JobTitle"]), Department = Db.S(r["Department"]), StartDate = Db.Date(r["StartDate"]),
        Status = Db.S(r["Status"]), ContractType = Db.S(r["ContractType"]), ContractStart = Db.DateN(r["ContractStart"]), ContractEnd = Db.DateN(r["ContractEnd"]),
        ProbationDays = Db.I(r["ProbationDays"]), Notes = Db.S(r["Notes"])
    };
}
