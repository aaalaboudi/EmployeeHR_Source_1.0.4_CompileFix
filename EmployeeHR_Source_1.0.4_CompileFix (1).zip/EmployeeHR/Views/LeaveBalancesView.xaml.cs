using System.Windows;
using System.Windows.Controls;
using EmployeeHR.Calculation;
using EmployeeHR.Models;
using EmployeeHR.Services;
using EmployeeHR.Utilities;

namespace EmployeeHR.Views;
public partial class LeaveBalancesView : UserControl
{
    private readonly EmployeeService _employees=new(); private readonly LeaveCalculationService _calc=new(); private readonly TerminationService _termination=new(); private LeaveBalanceResult? _last;
    public LeaveBalancesView(){InitializeComponent();AsOf.SelectedDate=DateTime.Today;Loaded+=(_,_)=>EmployeeBox.ItemsSource=_employees.GetAll();}
    private Employee? Selected=>EmployeeBox.SelectedItem as Employee;
    private void Employee_Changed(object sender,SelectionChangedEventArgs e)=>Refresh(); private void AsOf_Changed(object sender,SelectionChangedEventArgs e)=>Refresh(); private void Refresh_Click(object sender,RoutedEventArgs e)=>Refresh();
    private void Refresh(){if(Selected is null||AsOf.SelectedDate is null)return;try{_last=_calc.CalculateBalance(Selected.Id,AsOf.SelectedDate.Value,true);Opening.Text=$"{_last.OpeningBalance:N2}";Accrued.Text=$"{_last.Accrued:N2}";Used.Text=$"{_last.Used:N2}";Adjustments.Text=$"{_last.Adjustments:N2}";Balance.Text=$"{_last.CurrentBalance:N2}";Future.Text=$"{_last.FutureApproved:N2}";var target=_termination.Get(Selected.Id)?.LastWorkingDay??Selected.ContractEnd;Projected.Text=target.HasValue&&target.Value.Date>=Selected.StartDate.Date?$"{_calc.CalculateBalance(Selected.Id,target.Value,true).CurrentBalance:N2}":"--";Grid.ItemsSource=_calc.GetLedger(Selected.Id,AsOf.SelectedDate.Value);}catch(Exception ex){MessageBox.Show(ex.Message);}}
    private void Details_Click(object sender,RoutedEventArgs e){if(_last is not null)MessageBox.Show(_last.CalculationDetails,"تفاصيل حساب رصيد الإجازة",MessageBoxButton.OK,MessageBoxImage.Information);}
    private void Adjustment_Click(object sender,RoutedEventArgs e){if(Selected is null)return;var a=InputDialog.Show("أدخل قيمة التعديل بالأيام. استخدم قيمة سالبة للخصم.","تعديل رصيد الإجازة","0");if(!decimal.TryParse(a,out var value))return;var desc=InputDialog.Show("البيان/سبب التعديل","بيان التعديل","تعديل يدوي");_calc.AddAdjustment(Selected.Id,AsOf.SelectedDate??DateTime.Today,value,desc??"تعديل يدوي");Refresh();}
    private void Opening_Click(object sender,RoutedEventArgs e){if(Selected is null)return;var a=InputDialog.Show("أدخل الرصيد الافتتاحي بالأيام. سيتم استبدال أي رصيد افتتاحي سابق لهذا الموظف.","الرصيد الافتتاحي","0");if(!decimal.TryParse(a,out var value))return;var date=InputDialog.Show("تاريخ الرصيد الافتتاحي بصيغة YYYY-MM-DD","تاريخ الرصيد",Selected.StartDate.ToString("yyyy-MM-dd"));if(!DateTime.TryParse(date,out var d))d=Selected.StartDate;_calc.SetOpeningBalance(Selected.Id,d,value,"رصيد افتتاحي مرحل");Refresh();}
}
