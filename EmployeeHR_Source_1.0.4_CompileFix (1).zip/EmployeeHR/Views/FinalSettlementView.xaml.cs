using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using EmployeeHR.Calculation;
using EmployeeHR.Models;
using EmployeeHR.Services;

namespace EmployeeHR.Views;
public partial class FinalSettlementView : UserControl
{
    private readonly EmployeeService _employees=new(); private readonly FinalSettlementService _settlement=new(); private readonly ReportService _reports=new(); private FinalSettlementResult? _last;
    public FinalSettlementView(){InitializeComponent();AdjustmentType.SelectedIndex=0;CategoryBox.SelectedIndex=0;AdjustmentDate.SelectedDate=DateTime.Today;Loaded+=(_,_)=>EmployeeBox.ItemsSource=_employees.GetAll();}
    private Employee? Selected=>EmployeeBox.SelectedItem as Employee;
    private void Employee_Changed(object sender,SelectionChangedEventArgs e){ReloadAdjustments();Calculate();}
    private void Calculate_Click(object sender,RoutedEventArgs e)=>Calculate();
    private void Calculate(){if(Selected is null)return;try{_last=_settlement.Calculate(Selected.Id);EntitlementsText.Text=$"الراتب حتى آخر يوم عمل: {_last.SalaryUntilLastDay:N2} ريال\nمكافأة نهاية الخدمة: {_last.Eosb:N2} ريال\nرصيد الإجازة: {_last.LeaveDays:N2} يوم\nقيمة رصيد الإجازة: {_last.LeaveValue:N2} ريال\nتعويض إنهاء العقد: {_last.TerminationCompensation:N2} ريال\nمستحقات إضافية: {_last.PriorSalaryDue+_last.AllowancesDue+_last.CommissionsDue+_last.ExpensesDue+_last.OtherEntitlements:N2} ريال\n\nإجمالي المستحقات: {_last.TotalEntitlements:N2} ريال";DeductionsText.Text=$"السلف: {_last.Advances:N2} ريال\nالقروض: {_last.Loans:N2} ريال\nخصومات نظامية: {_last.StatutoryDeductions:N2} ريال\nمبالغ لصاحب العمل: {_last.EmployerReceivables:N2} ريال\nخصومات أخرى: {_last.OtherDeductions:N2} ريال\n\nإجمالي الخصومات: {_last.TotalDeductions:N2} ريال";Net.Text=$"{_last.NetSettlement:N2} ريال";}catch(Exception ex){MessageBox.Show(ex.Message,"تعذر الاحتساب",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    private void Details_Click(object sender,RoutedEventArgs e){if(_last is not null)MessageBox.Show(_last.CalculationDetails,"تفاصيل حساب التصفية",MessageBoxButton.OK,MessageBoxImage.Information);}
    private void AddAdjustment_Click(object sender,RoutedEventArgs e){if(Selected is null)return;try{var category=CategoryBox.Text;var isDeduction=(AdjustmentType.SelectedItem as ComboBoxItem)?.Content?.ToString()=="خصم";if(!decimal.TryParse(AdjustmentAmount.Text,out var amount))throw new InvalidOperationException("أدخل مبلغًا صحيحًا.");_settlement.AddAdjustment(Selected.Id,category,AdjustmentDescription.Text,amount,isDeduction,AdjustmentDate.SelectedDate??DateTime.Today);ReloadAdjustments();Calculate();AdjustmentAmount.Clear();AdjustmentDescription.Clear();}catch(Exception ex){MessageBox.Show(ex.Message);}}
    private void ReloadAdjustments(){AdjustmentsGrid.ItemsSource=Selected is null?null:_settlement.GetAdjustmentRows(Selected.Id);}
    private void Pdf_Click(object sender,RoutedEventArgs e){if(_last is null)Calculate();if(_last is null)return;try{var path=_reports.ExportFinalSettlementPdf(_last);MessageBox.Show($"تم إنشاء الملف:\n{path}","تم التصدير");Process.Start(new ProcessStartInfo("explorer.exe",$"/select,\"{path}\""){UseShellExecute=true});}catch(Exception ex){MessageBox.Show(ex.Message,"تعذر التصدير",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    private void Print_Click(object sender,RoutedEventArgs e){if(_last is null)Calculate();if(_last is not null)_reports.PrintFinalSettlement(_last);}
}
