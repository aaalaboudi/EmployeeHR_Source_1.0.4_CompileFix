using System.Windows;
using System.Windows.Controls;
using EmployeeHR.Models;
using EmployeeHR.Services;

namespace EmployeeHR.Views;
public partial class LeavesView : UserControl
{
    private readonly EmployeeService _employees=new(); private readonly LeaveService _leaves=new();
    public LeavesView(){InitializeComponent();StartDate.SelectedDate=DateTime.Today;EndDate.SelectedDate=DateTime.Today;TypeBox.SelectedIndex=0;StatusBox.SelectedIndex=0;Loaded+=(_,_)=>{EmployeeBox.ItemsSource=_employees.GetActive();Reload();UpdateDays();};}
    private void Reload(){Grid.ItemsSource=_leaves.GetAll();}
    private void Date_Changed(object sender,SelectionChangedEventArgs e)=>UpdateDays();
    private void UpdateDays(){try{if(StartDate?.SelectedDate is DateTime s&&EndDate?.SelectedDate is DateTime e)Days.Text=_leaves.CountDays(s,e).ToString();}catch{if(Days is not null)Days.Text="-";}}
    private static string C(ComboBox x)=>(x.SelectedItem as ComboBoxItem)?.Content?.ToString()??"";
    private void Save_Click(object sender,RoutedEventArgs e){try{var emp=EmployeeBox.SelectedItem as Employee??throw new InvalidOperationException("اختر الموظف.");var l=new LeaveRequest{EmployeeId=emp.Id,StartDate=StartDate.SelectedDate??DateTime.Today,EndDate=EndDate.SelectedDate??DateTime.Today,LeaveType=C(TypeBox),Status=C(StatusBox),Notes=Notes.Text};_leaves.Add(l);Reload();MessageBox.Show("تم تسجيل الإجازة.");}catch(Exception ex){MessageBox.Show(ex.Message,"تعذر التسجيل",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    private void Approve_Click(object sender,RoutedEventArgs e){if(Grid.SelectedItem is LeaveRequest x){_leaves.SetStatus(x.Id,"معتمدة");Reload();}}
    private void Cancel_Click(object sender,RoutedEventArgs e){if(Grid.SelectedItem is LeaveRequest x){_leaves.SetStatus(x.Id,"ملغاة");Reload();}}
}
