using System.Windows;
using System.Windows.Controls;
using EmployeeHR.Calculation;
using EmployeeHR.Models;
using EmployeeHR.Repositories;
using EmployeeHR.Services;

namespace EmployeeHR.Views;
public partial class TerminationView : UserControl
{
    private readonly EmployeeService _employees=new(); private readonly TerminationService _termination=new(); private readonly EndOfServiceBenefitService _eosb=new(); private readonly TerminationCompensationService _compensation=new();
    public TerminationView(){InitializeComponent();LastDay.SelectedDate=DateTime.Today;Loaded+=(_,_)=>{EmployeeBox.ItemsSource=_employees.GetAll();ReasonBox.ItemsSource=_termination.GetReasons();};}
    private Employee? Selected=>EmployeeBox.SelectedItem as Employee;
    private void Employee_Changed(object sender,SelectionChangedEventArgs e){if(Selected is not { } emp)return;ContractType.Text=emp.ContractType;var t=_termination.Get(emp.Id);if(t is null){LastDay.SelectedDate=DateTime.Today;return;}LastDay.SelectedDate=t.LastWorkingDay;SelectReason(t.Reason);InitiatedBy.Text=t.InitiatedBy;Article.Text=t.LegalArticle;Notes.Text=t.Notes;HasCompClause.IsChecked=t.HasContractCompensationClause;CompMethod.Text=t.CompensationMethod;CompAmount.Text=t.CompensationAmount.ToString("N2");Preview();}
    private void Reason_Changed(object sender,SelectionChangedEventArgs e){if(ReasonBox.SelectedItem is TerminationReason r){InitiatedBy.Text=r.InitiatedBy;Article.Text=r.Article;}}
    private void SelectReason(string name){foreach(var item in ReasonBox.Items)if(item is TerminationReason r&&r.Name==name){ReasonBox.SelectedItem=item;return;}}
    private void Save_Click(object sender,RoutedEventArgs e){try{var emp=Selected??throw new InvalidOperationException("اختر الموظف.");var reason=ReasonBox.SelectedItem as TerminationReason;var t=new TerminationRecord{EmployeeId=emp.Id,LastWorkingDay=LastDay.SelectedDate??DateTime.Today,Reason=reason?.Name??"سبب آخر",InitiatedBy=InitiatedBy.Text,LegalArticle=Article.Text,Notes=Notes.Text,HasContractCompensationClause=HasCompClause.IsChecked==true,CompensationMethod=CompMethod.Text,CompensationAmount=decimal.TryParse(CompAmount.Text,out var c)?c:0m};_termination.Save(t);Preview();MessageBox.Show("تم حفظ بيانات انتهاء الخدمة.");}catch(Exception ex){MessageBox.Show(ex.Message,"تعذر الحفظ",MessageBoxButton.OK,MessageBoxImage.Warning);}}

    private void Article77_Click(object sender,RoutedEventArgs e)
    {
        try
        {
            var emp=Selected??throw new InvalidOperationException("اختر الموظف.");
            if(HasCompClause.IsChecked==true)
            {
                MessageBox.Show("تم تحديد وجود شرط تعويض في العقد. راجع نص الشرط وأدخل قيمته/طريقة احتسابه بدل استخدام القاعدة الاسترشادية للمادة 77.","تعويض العقد",MessageBoxButton.OK,MessageBoxImage.Information);
                return;
            }
            var r=_compensation.CalculateArticle77(emp,LastDay.SelectedDate??DateTime.Today);
            CompAmount.Text=r.Amount.ToString("N2");
            CompMethod.Text=r.Method;
            if(string.IsNullOrWhiteSpace(Article.Text)) Article.Text="المادة 77";
            MessageBox.Show(r.Details,"احتساب استرشادي للمادة 77",MessageBoxButton.OK,MessageBoxImage.Information);
        }
        catch(Exception ex){MessageBox.Show(ex.Message,"تعذر الاحتساب",MessageBoxButton.OK,MessageBoxImage.Warning);}
    }
    private void Preview_Click(object sender,RoutedEventArgs e)=>Preview();
    private void Preview(){if(Selected is not { } emp||LastDay.SelectedDate is null)return;try{var reason=(ReasonBox.SelectedItem as TerminationReason)?.Name??_termination.Get(emp.Id)?.Reason??"انتهاء العقد";Details.Text=_eosb.Calculate(emp,LastDay.SelectedDate.Value,reason,false,Article.Text).Details;}catch(Exception ex){Details.Text=ex.Message;}}
}
