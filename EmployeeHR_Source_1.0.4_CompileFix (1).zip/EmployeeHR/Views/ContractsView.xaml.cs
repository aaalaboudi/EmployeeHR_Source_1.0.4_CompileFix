using System.Windows;
using System.Windows.Controls;
using EmployeeHR.Models;
using EmployeeHR.Services;

namespace EmployeeHR.Views;
public partial class ContractsView : UserControl
{
    private readonly EmployeeService _employees=new(); private readonly ContractService _contracts=new();
    public ContractsView(){InitializeComponent();TypeBox.SelectedIndex=0;StartDate.SelectedDate=DateTime.Today;EffectiveFrom.SelectedDate=DateTime.Today;Loaded+=(_,_)=>{EmployeeBox.ItemsSource=_employees.GetAll();};}
    private Employee? Selected=>EmployeeBox.SelectedItem as Employee;
    private void EmployeeBox_SelectionChanged(object sender,SelectionChangedEventArgs e){Reload();if(Selected is { } x){TypeBox.SelectedIndex=x.ContractType=="غير محدد المدة"?1:0;StartDate.SelectedDate=x.ContractStart??x.StartDate;EndDate.SelectedDate=x.ContractEnd;ProbationDays.Text=x.ProbationDays.ToString();}}
    private void Reload(){Grid.ItemsSource=Selected is null?null:_contracts.GetHistory(Selected.Id);}
    private void Save_Click(object sender,RoutedEventArgs e){try{var emp=Selected??throw new InvalidOperationException("اختر الموظف.");var c=new ContractRecord{EmployeeId=emp.Id,ContractType=(TypeBox.SelectedItem as ComboBoxItem)?.Content?.ToString()??"محدد المدة",StartDate=StartDate.SelectedDate??DateTime.Today,EndDate=EndDate.SelectedDate,ProbationDays=int.TryParse(ProbationDays.Text,out var p)?p:0,EffectiveFrom=EffectiveFrom.SelectedDate??DateTime.Today,EffectiveTo=EffectiveTo.SelectedDate,Notes=Notes.Text};_contracts.Add(c);Reload();MessageBox.Show("تم حفظ العقد وتحديث سجل العقود.");}catch(Exception ex){MessageBox.Show(ex.Message,"تعذر الحفظ",MessageBoxButton.OK,MessageBoxImage.Warning);}}
}
