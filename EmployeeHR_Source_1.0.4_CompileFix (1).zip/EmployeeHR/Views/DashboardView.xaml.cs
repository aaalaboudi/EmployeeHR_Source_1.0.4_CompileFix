using System.Windows.Controls;
using EmployeeHR.Services;

namespace EmployeeHR.Views;
public partial class DashboardView : UserControl
{
    public DashboardView(){InitializeComponent();Loaded += (_,_)=>Refresh();}
    private void Refresh(){var m=new DashboardService().GetMetrics();Total.Text=m.TotalEmployees.ToString();Active.Text=m.ActiveEmployees.ToString();Terminated.Text=m.TerminatedEmployees.ToString();Contracts.Text=m.ContractsExpiringSoon.ToString();Iqamas.Text=m.IqamasExpiringSoon.ToString();CurrentLeaves.Text=m.CurrentLeaves.ToString();UpcomingLeaves.Text=m.UpcomingLeaves.ToString();LeaveBalances.Text=$"{m.TotalLeaveBalances:N2} يوم";HighBalances.Text=m.HighLeaveBalanceEmployees.ToString();FiveYears.Text=m.ApproachingFiveYears.ToString();}
}
