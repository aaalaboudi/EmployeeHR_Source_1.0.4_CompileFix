using System.Windows;
using System.Windows.Controls;
using EmployeeHR.Models;
using EmployeeHR.Services;

namespace EmployeeHR.Views;
public partial class EmployeesView : UserControl
{
    private readonly EmployeeService _service=new(); private long _id;
    public EmployeesView(){InitializeComponent();StartDate.SelectedDate=DateTime.Today;Status.SelectedIndex=0;ContractType.SelectedIndex=0;Loaded+=(_,_)=>Reload();}
    private void Reload(){Grid.ItemsSource=_service.GetAll();}
    private void Grid_SelectionChanged(object sender,SelectionChangedEventArgs e){if(Grid.SelectedItem is not Employee x)return;_id=x.Id;EmployeeNumber.Text=x.EmployeeNumber;ArabicName.Text=x.ArabicName;EnglishName.Text=x.EnglishName;Nationality.Text=x.Nationality;NationalId.Text=x.NationalId;IqamaExpiry.SelectedDate=x.IqamaExpiry;BirthDate.SelectedDate=x.BirthDate;Mobile.Text=x.Mobile;JobTitle.Text=x.JobTitle;Department.Text=x.Department;StartDate.SelectedDate=x.StartDate;Select(Status,x.Status);Select(ContractType,x.ContractType);ContractStart.SelectedDate=x.ContractStart;ContractEnd.SelectedDate=x.ContractEnd;ProbationDays.Text=x.ProbationDays.ToString();Notes.Text=x.Notes;}
    private void New_Click(object sender,RoutedEventArgs e){_id=0;foreach(var tb in new[]{EmployeeNumber,ArabicName,EnglishName,Nationality,NationalId,Mobile,JobTitle,Department,ProbationDays,Notes})tb.Clear();IqamaExpiry.SelectedDate=null;BirthDate.SelectedDate=null;StartDate.SelectedDate=DateTime.Today;ContractStart.SelectedDate=null;ContractEnd.SelectedDate=null;Status.SelectedIndex=0;ContractType.SelectedIndex=0;Grid.SelectedItem=null;}
    private void Save_Click(object sender,RoutedEventArgs e){try{var x=new Employee{Id=_id,EmployeeNumber=EmployeeNumber.Text,ArabicName=ArabicName.Text,EnglishName=EnglishName.Text,Nationality=Nationality.Text,NationalId=NationalId.Text,IqamaExpiry=IqamaExpiry.SelectedDate,BirthDate=BirthDate.SelectedDate,Mobile=Mobile.Text,JobTitle=JobTitle.Text,Department=Department.Text,StartDate=StartDate.SelectedDate??DateTime.Today,Status=Text(Status),ContractType=Text(ContractType),ContractStart=ContractStart.SelectedDate,ContractEnd=ContractEnd.SelectedDate,ProbationDays=int.TryParse(ProbationDays.Text,out var p)?p:0,Notes=Notes.Text};_id=_service.Save(x);Reload();MessageBox.Show("تم حفظ بيانات الموظف.","EmployeeHR",MessageBoxButton.OK,MessageBoxImage.Information);}catch(Exception ex){MessageBox.Show(ex.Message,"تعذر الحفظ",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    private static string Text(ComboBox c)=>(c.SelectedItem as ComboBoxItem)?.Content?.ToString()??""; private static void Select(ComboBox c,string value){foreach(ComboBoxItem i in c.Items)if(i.Content?.ToString()==value){c.SelectedItem=i;break;}}
}
