using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using EmployeeHR.Services;
using EmployeeHR.Utilities;

namespace EmployeeHR.Views;
public partial class ReportsView : UserControl
{
    private readonly ReportService _reports=new(); private List<Dictionary<string,object?>> _rows=new(); private string _title="تقرير";
    public ReportsView(){InitializeComponent();AsOf.SelectedDate=DateTime.Today;ReportBox.SelectedIndex=0;Loaded+=(_,_)=>LoadReport();}
    private string Key=>(ReportBox.SelectedItem as ComboBoxItem)?.Tag?.ToString()??"Employees";
    private void Report_Changed(object sender,SelectionChangedEventArgs e){if(IsLoaded)LoadReport();}
    private void Load_Click(object sender,RoutedEventArgs e)=>LoadReport();
    private void LoadReport(){try{_title=(ReportBox.SelectedItem as ComboBoxItem)?.Content?.ToString()??"تقرير";_rows=Key switch{"LeaveBalance"=>_reports.GetLeaveBalanceReport(AsOf.SelectedDate??DateTime.Today),"EndOfService"=>_reports.GetEndOfServiceReport(),"FinalSettlement"=>_reports.GetFinalSettlementReport(),_=>_reports.GetReport(Key)};BindRows();}catch(Exception ex){MessageBox.Show(ex.Message,"تعذر إعداد التقرير",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    private void BindRows(){Grid.Columns.Clear();if(_rows.Count==0){Grid.ItemsSource=null;return;}foreach(var h in _rows[0].Keys)Grid.Columns.Add(new DataGridTextColumn{Header=h,Binding=new Binding($"[{h}]"){StringFormat=h.Contains("تاريخ")||h.Contains("انتهاء")?"yyyy/MM/dd":null},Width=DataGridLength.Auto});Grid.ItemsSource=_rows;}
    private void Excel_Click(object sender,RoutedEventArgs e){try{var p=_reports.ExportXlsx(_title,_rows);ShowFile(p);}catch(Exception ex){MessageBox.Show(ex.Message);}}
    private void Pdf_Click(object sender,RoutedEventArgs e){try{var p=_reports.ExportPdf(_title,_rows);ShowFile(p);}catch(Exception ex){MessageBox.Show(ex.Message);}}
    private void Print_Click(object sender,RoutedEventArgs e){try{_reports.Print(_title,_rows);}catch(Exception ex){MessageBox.Show(ex.Message);}}
    private static void ShowFile(string p){MessageBox.Show($"تم إنشاء الملف:\n{p}");Process.Start(new ProcessStartInfo("explorer.exe",$"/select,\"{p}\""){UseShellExecute=true});}
    private void OpenFolder_Click(object sender,RoutedEventArgs e)=>Process.Start(new ProcessStartInfo("explorer.exe",AppPaths.ExportsDirectory){UseShellExecute=true});
}
