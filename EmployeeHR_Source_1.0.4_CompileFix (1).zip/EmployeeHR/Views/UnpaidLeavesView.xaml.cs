using System.Windows;
using System.Windows.Controls;
using EmployeeHR.Models;
using EmployeeHR.Services;

namespace EmployeeHR.Views;
public partial class UnpaidLeavesView : UserControl
{
    private readonly EmployeeService _employees=new(); private readonly LeaveService _leaves=new();
    public UnpaidLeavesView(){InitializeComponent();StartDate.SelectedDate=DateTime.Today;EndDate.SelectedDate=DateTime.Today;Loaded+=(_,_)=>{EmployeeBox.ItemsSource=_employees.GetActive();Reload();};}
    private void Reload()=>Grid.ItemsSource=_leaves.GetUnpaid();
    private void Save_Click(object sender,RoutedEventArgs e){try{var emp=EmployeeBox.SelectedItem as Employee??throw new InvalidOperationException("اختر الموظف.");var u=new UnpaidLeave{EmployeeId=emp.Id,StartDate=StartDate.SelectedDate??DateTime.Today,EndDate=EndDate.SelectedDate??DateTime.Today,Reason=Reason.Text,Notes=Notes.Text,AffectsService=AffectsService.IsChecked==true,AffectsLeaveAccrual=AffectsAccrual.IsChecked==true,ContractSuspended=ContractSuspended.IsChecked==true};_leaves.AddUnpaid(u);Reload();MessageBox.Show("تم حفظ الإجازة بدون أجر ومعالجتها وفق الخيارات المحددة.");}catch(Exception ex){MessageBox.Show(ex.Message,"تعذر الحفظ",MessageBoxButton.OK,MessageBoxImage.Warning);}}
}
