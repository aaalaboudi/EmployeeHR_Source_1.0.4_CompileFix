using System.Windows;
using System.Windows.Controls;
using EmployeeHR.Models;
using EmployeeHR.Services;

namespace EmployeeHR.Views;
public partial class SalariesView : UserControl
{
    private readonly EmployeeService _employees=new(); private readonly SalaryService _salary=new();
    public SalariesView(){InitializeComponent();EffectiveFrom.SelectedDate=DateTime.Today;Loaded+=(_,_)=>EmployeeBox.ItemsSource=_employees.GetAll();}
    private Employee? Selected=>EmployeeBox.SelectedItem as Employee;
    private void EmployeeBox_SelectionChanged(object sender,SelectionChangedEventArgs e){Reload();}
    private void Reload(){Grid.ItemsSource=Selected is null?null:_salary.GetHistory(Selected.Id);}
    private static decimal V(TextBox t)=>decimal.TryParse(t.Text,out var v)?v:0m;
    private void Amount_Changed(object sender,TextChangedEventArgs e){if(Gross is not null)Gross.Text=(V(Basic)+V(Housing)+V(Transport)+V(Food)+V(OtherFixed)+V(Commissions)+V(Variable)).ToString("N2");}
    private void Save_Click(object sender,RoutedEventArgs e){try{var emp=Selected??throw new InvalidOperationException("اختر الموظف.");var s=new SalaryRecord{EmployeeId=emp.Id,EffectiveFrom=EffectiveFrom.SelectedDate??DateTime.Today,EffectiveTo=EffectiveTo.SelectedDate,BasicSalary=V(Basic),HousingAllowance=V(Housing),TransportationAllowance=V(Transport),FoodAllowance=V(Food),OtherFixedAllowances=V(OtherFixed),Commissions=V(Commissions),VariableAllowances=V(Variable)};_salary.Add(s);Reload();MessageBox.Show("تم حفظ الراتب كسجل تاريخي جديد.");}catch(Exception ex){MessageBox.Show(ex.Message,"تعذر الحفظ",MessageBoxButton.OK,MessageBoxImage.Warning);}}
}
