namespace EmployeeHR.Data.Migrations;

public static class Migration001
{
    public const int Version = 1;
    public const string Sql = @"
CREATE TABLE IF NOT EXISTS SchemaVersion(
    Version INTEGER NOT NULL PRIMARY KEY,
    AppliedAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS Employees(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EmployeeNumber TEXT NOT NULL UNIQUE,
    ArabicName TEXT NOT NULL,
    EnglishName TEXT NOT NULL DEFAULT '',
    Nationality TEXT NOT NULL DEFAULT '',
    NationalId TEXT NOT NULL UNIQUE,
    IqamaExpiry TEXT NULL,
    BirthDate TEXT NULL,
    Mobile TEXT NOT NULL DEFAULT '',
    JobTitle TEXT NOT NULL DEFAULT '',
    Department TEXT NOT NULL DEFAULT '',
    StartDate TEXT NOT NULL,
    Status TEXT NOT NULL DEFAULT 'على رأس العمل',
    ContractType TEXT NOT NULL DEFAULT 'محدد المدة',
    ContractStart TEXT NULL,
    ContractEnd TEXT NULL,
    ProbationDays INTEGER NOT NULL DEFAULT 0,
    Notes TEXT NOT NULL DEFAULT '',
    CreatedAt TEXT NOT NULL,
    UpdatedAt TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS IX_Employees_Status ON Employees(Status);
CREATE INDEX IF NOT EXISTS IX_Employees_ContractEnd ON Employees(ContractEnd);
CREATE INDEX IF NOT EXISTS IX_Employees_IqamaExpiry ON Employees(IqamaExpiry);

CREATE TABLE IF NOT EXISTS Contracts(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EmployeeId INTEGER NOT NULL REFERENCES Employees(Id) ON DELETE CASCADE,
    ContractType TEXT NOT NULL,
    StartDate TEXT NOT NULL,
    EndDate TEXT NULL,
    ProbationDays INTEGER NOT NULL DEFAULT 0,
    EffectiveFrom TEXT NOT NULL,
    EffectiveTo TEXT NULL,
    Notes TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS IX_Contracts_Employee ON Contracts(EmployeeId, EffectiveFrom);

CREATE TABLE IF NOT EXISTS SalaryComponents(
    Code TEXT PRIMARY KEY,
    ArabicName TEXT NOT NULL,
    IncludeInEosb INTEGER NOT NULL DEFAULT 1,
    IncludeInLeave INTEGER NOT NULL DEFAULT 1,
    IncludeInOther INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS SalaryHistory(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EmployeeId INTEGER NOT NULL REFERENCES Employees(Id) ON DELETE CASCADE,
    EffectiveFrom TEXT NOT NULL,
    EffectiveTo TEXT NULL,
    BasicSalary REAL NOT NULL DEFAULT 0,
    HousingAllowance REAL NOT NULL DEFAULT 0,
    TransportationAllowance REAL NOT NULL DEFAULT 0,
    FoodAllowance REAL NOT NULL DEFAULT 0,
    OtherFixedAllowances REAL NOT NULL DEFAULT 0,
    Commissions REAL NOT NULL DEFAULT 0,
    VariableAllowances REAL NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS IX_SalaryHistory_EmployeeDate ON SalaryHistory(EmployeeId, EffectiveFrom, EffectiveTo);

CREATE TABLE IF NOT EXISTS LeaveRules(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    RuleName TEXT NOT NULL,
    MinServiceYears REAL NOT NULL,
    MaxServiceYears REAL NULL,
    AnnualEntitlementDays REAL NOT NULL,
    EffectiveFrom TEXT NOT NULL,
    EffectiveTo TEXT NULL,
    ArticleRef TEXT NOT NULL DEFAULT '',
    Notes TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS EosbRules(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    RuleName TEXT NOT NULL,
    SegmentStartYears REAL NOT NULL,
    SegmentEndYears REAL NULL,
    MonthsPerServiceYear REAL NOT NULL,
    EffectiveFrom TEXT NOT NULL,
    EffectiveTo TEXT NULL,
    ArticleRef TEXT NOT NULL DEFAULT '',
    Notes TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS ResignationEntitlementRules(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    RuleName TEXT NOT NULL,
    MinServiceYears REAL NOT NULL,
    MaxServiceYears REAL NULL,
    EntitlementRate REAL NOT NULL,
    MinInclusive INTEGER NOT NULL DEFAULT 1,
    MaxInclusive INTEGER NOT NULL DEFAULT 0,
    EffectiveFrom TEXT NOT NULL,
    EffectiveTo TEXT NULL,
    ArticleRef TEXT NOT NULL DEFAULT '',
    Notes TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS TerminationReasons(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    ArabicName TEXT NOT NULL UNIQUE,
    DefaultInitiatedBy TEXT NOT NULL DEFAULT '',
    LegalArticle TEXT NOT NULL DEFAULT '',
    FullEosbException INTEGER NOT NULL DEFAULT 0,
    Active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS LeaveRequests(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EmployeeId INTEGER NOT NULL REFERENCES Employees(Id) ON DELETE CASCADE,
    StartDate TEXT NOT NULL,
    EndDate TEXT NOT NULL,
    DaysCount REAL NOT NULL,
    LeaveType TEXT NOT NULL,
    Status TEXT NOT NULL,
    Notes TEXT NOT NULL DEFAULT '',
    CreatedAt TEXT NOT NULL,
    UpdatedAt TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS IX_LeaveRequests_EmployeeDate ON LeaveRequests(EmployeeId, StartDate, EndDate);

CREATE TABLE IF NOT EXISTS UnpaidLeaves(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EmployeeId INTEGER NOT NULL REFERENCES Employees(Id) ON DELETE CASCADE,
    StartDate TEXT NOT NULL,
    EndDate TEXT NOT NULL,
    DaysCount INTEGER NOT NULL,
    Reason TEXT NOT NULL DEFAULT '',
    Notes TEXT NOT NULL DEFAULT '',
    AffectsService INTEGER NOT NULL DEFAULT 0,
    AffectsLeaveAccrual INTEGER NOT NULL DEFAULT 0,
    ContractSuspended INTEGER NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS IX_UnpaidLeaves_EmployeeDate ON UnpaidLeaves(EmployeeId, StartDate, EndDate);

CREATE TABLE IF NOT EXISTS LeaveLedger(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EmployeeId INTEGER NOT NULL REFERENCES Employees(Id) ON DELETE CASCADE,
    EntryDate TEXT NOT NULL,
    EntryType TEXT NOT NULL,
    Description TEXT NOT NULL,
    Accrued REAL NOT NULL DEFAULT 0,
    Used REAL NOT NULL DEFAULT 0,
    Adjustment REAL NOT NULL DEFAULT 0,
    SystemGenerated INTEGER NOT NULL DEFAULT 0,
    SourceId INTEGER NULL,
    CreatedAt TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS IX_LeaveLedger_EmployeeDate ON LeaveLedger(EmployeeId, EntryDate);

CREATE TABLE IF NOT EXISTS Terminations(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EmployeeId INTEGER NOT NULL REFERENCES Employees(Id) ON DELETE CASCADE,
    LastWorkingDay TEXT NOT NULL,
    Reason TEXT NOT NULL,
    InitiatedBy TEXT NOT NULL,
    LegalArticle TEXT NOT NULL DEFAULT '',
    Notes TEXT NOT NULL DEFAULT '',
    HasContractCompensationClause INTEGER NOT NULL DEFAULT 0,
    CompensationMethod TEXT NOT NULL DEFAULT '',
    CompensationAmount REAL NOT NULL DEFAULT 0,
    CreatedAt TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS UX_Terminations_Employee ON Terminations(EmployeeId);

CREATE TABLE IF NOT EXISTS SettlementAdjustments(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EmployeeId INTEGER NOT NULL REFERENCES Employees(Id) ON DELETE CASCADE,
    Category TEXT NOT NULL,
    Description TEXT NOT NULL,
    Amount REAL NOT NULL,
    IsDeduction INTEGER NOT NULL DEFAULT 0,
    EffectiveDate TEXT NOT NULL,
    Notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS Settings(
    Key TEXT PRIMARY KEY,
    Value TEXT NOT NULL,
    UpdatedAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS AuditLog(
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    EventAt TEXT NOT NULL,
    Action TEXT NOT NULL,
    EntityType TEXT NOT NULL,
    EntityId TEXT NOT NULL DEFAULT '',
    Details TEXT NOT NULL DEFAULT '',
    WindowsUser TEXT NOT NULL DEFAULT '',
    MachineName TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS IX_AuditLog_EventAt ON AuditLog(EventAt);
";
}
