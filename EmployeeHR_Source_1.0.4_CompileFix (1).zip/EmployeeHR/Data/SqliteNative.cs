using System.Runtime.InteropServices;
using System.Text;
using System.Globalization;

namespace EmployeeHR.Data;

internal sealed class SqliteConnectionLite : IDisposable
{
    private const int SQLITE_OK = 0;
    private const int SQLITE_ROW = 100;
    private const int SQLITE_DONE = 101;
    private const int SQLITE_INTEGER = 1;
    private const int SQLITE_FLOAT = 2;
    private const int SQLITE_TEXT = 3;
    private const int SQLITE_BLOB = 4;
    private const int SQLITE_NULL = 5;
    private const int SQLITE_OPEN_READWRITE = 0x00000002;
    private const int SQLITE_OPEN_CREATE = 0x00000004;
    private const int SQLITE_OPEN_FULLMUTEX = 0x00010000;
    private static readonly IntPtr SQLITE_TRANSIENT = new(-1);

    private IntPtr _db;

    public SqliteConnectionLite(string path)
    {
        var bytes = Utf8Z(path);
        var rc = Native.sqlite3_open_v2(bytes, out _db, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX, IntPtr.Zero);
        if (rc != SQLITE_OK) throw new InvalidOperationException($"SQLite open error ({rc}): {GetError()}");
        Execute("PRAGMA foreign_keys = ON;");
        Execute("PRAGMA busy_timeout = 5000;");
    }

    public void Execute(string sql, IReadOnlyDictionary<string, object?>? parameters = null)
    {
        using var stmt = Prepare(sql, parameters);
        var rc = Native.sqlite3_step(stmt.Handle);
        if (rc != SQLITE_DONE && rc != SQLITE_ROW) throw new InvalidOperationException($"SQLite execute error ({rc}): {GetError()}\nSQL: {sql}");
        while (rc == SQLITE_ROW) rc = Native.sqlite3_step(stmt.Handle);
        if (rc != SQLITE_DONE) throw new InvalidOperationException($"SQLite execute error ({rc}): {GetError()}\nSQL: {sql}");
    }

    public long ExecuteInsert(string sql, IReadOnlyDictionary<string, object?>? parameters = null)
    {
        Execute(sql, parameters);
        return Native.sqlite3_last_insert_rowid(_db);
    }

    public object? Scalar(string sql, IReadOnlyDictionary<string, object?>? parameters = null)
    {
        using var stmt = Prepare(sql, parameters);
        var rc = Native.sqlite3_step(stmt.Handle);
        if (rc == SQLITE_DONE) return null;
        if (rc != SQLITE_ROW) throw new InvalidOperationException($"SQLite scalar error ({rc}): {GetError()}\nSQL: {sql}");
        return ReadColumn(stmt.Handle, 0);
    }

    public List<Dictionary<string, object?>> Query(string sql, IReadOnlyDictionary<string, object?>? parameters = null)
    {
        using var stmt = Prepare(sql, parameters);
        var rows = new List<Dictionary<string, object?>>();
        while (true)
        {
            var rc = Native.sqlite3_step(stmt.Handle);
            if (rc == SQLITE_DONE) break;
            if (rc != SQLITE_ROW) throw new InvalidOperationException($"SQLite query error ({rc}): {GetError()}\nSQL: {sql}");
            var cols = Native.sqlite3_column_count(stmt.Handle);
            var row = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < cols; i++)
            {
                var name = PtrToStringUtf8(Native.sqlite3_column_name(stmt.Handle, i));
                row[name] = ReadColumn(stmt.Handle, i);
            }
            rows.Add(row);
        }
        return rows;
    }

    public void Begin() => Execute("BEGIN IMMEDIATE;");
    public void Commit() => Execute("COMMIT;");
    public void Rollback() { try { Execute("ROLLBACK;"); } catch { } }

    private PreparedStatement Prepare(string sql, IReadOnlyDictionary<string, object?>? parameters)
    {
        var sqlBytes = Utf8Z(sql);
        var rc = Native.sqlite3_prepare_v2(_db, sqlBytes, -1, out var stmt, IntPtr.Zero);
        if (rc != SQLITE_OK) throw new InvalidOperationException($"SQLite prepare error ({rc}): {GetError()}\nSQL: {sql}");
        var prepared = new PreparedStatement(stmt);
        if (parameters is not null)
        {
            foreach (var pair in parameters)
            {
                var name = pair.Key.StartsWith('@') ? pair.Key : "@" + pair.Key;
                var index = Native.sqlite3_bind_parameter_index(stmt, Utf8Z(name));
                if (index <= 0) continue;
                Bind(stmt, index, pair.Value);
            }
        }
        return prepared;
    }

    private static void Bind(IntPtr stmt, int index, object? value)
    {
        int rc;
        if (value is null || value is DBNull)
            rc = Native.sqlite3_bind_null(stmt, index);
        else if (value is bool b)
            rc = Native.sqlite3_bind_int(stmt, index, b ? 1 : 0);
        else if (value is byte or short or int or long)
            rc = Native.sqlite3_bind_int64(stmt, index, Convert.ToInt64(value));
        else if (value is float or double)
            rc = Native.sqlite3_bind_double(stmt, index, Convert.ToDouble(value));
        else if (value is decimal dec)
            rc = Native.sqlite3_bind_double(stmt, index, Convert.ToDouble(dec));
        else if (value is DateTime dt)
            rc = Native.sqlite3_bind_text(stmt, index, Utf8Z(dt.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)), -1, SQLITE_TRANSIENT);
        else
            rc = Native.sqlite3_bind_text(stmt, index, Utf8Z(Convert.ToString(value) ?? ""), -1, SQLITE_TRANSIENT);
        if (rc != SQLITE_OK) throw new InvalidOperationException($"SQLite bind error: {rc}");
    }

    private static object? ReadColumn(IntPtr stmt, int index)
    {
        return Native.sqlite3_column_type(stmt, index) switch
        {
            SQLITE_INTEGER => Native.sqlite3_column_int64(stmt, index),
            SQLITE_FLOAT => Native.sqlite3_column_double(stmt, index),
            SQLITE_TEXT => PtrToStringUtf8(Native.sqlite3_column_text(stmt, index)),
            SQLITE_BLOB => ReadBlob(stmt, index),
            SQLITE_NULL => null,
            _ => null
        };
    }

    private static byte[] ReadBlob(IntPtr stmt, int index)
    {
        var ptr = Native.sqlite3_column_blob(stmt, index);
        var len = Native.sqlite3_column_bytes(stmt, index);
        if (ptr == IntPtr.Zero || len <= 0) return Array.Empty<byte>();
        var data = new byte[len];
        Marshal.Copy(ptr, data, 0, len);
        return data;
    }

    private string GetError() => PtrToStringUtf8(Native.sqlite3_errmsg(_db));

    private static byte[] Utf8Z(string value)
    {
        var raw = Encoding.UTF8.GetBytes(value);
        var bytes = new byte[raw.Length + 1];
        Buffer.BlockCopy(raw, 0, bytes, 0, raw.Length);
        return bytes;
    }

    private static string PtrToStringUtf8(IntPtr ptr)
    {
        if (ptr == IntPtr.Zero) return "";
        var len = 0;
        while (Marshal.ReadByte(ptr, len) != 0) len++;
        var bytes = new byte[len];
        Marshal.Copy(ptr, bytes, 0, len);
        return Encoding.UTF8.GetString(bytes);
    }

    public void Dispose()
    {
        if (_db == IntPtr.Zero) return;
        Native.sqlite3_close_v2(_db);
        _db = IntPtr.Zero;
    }

    private sealed class PreparedStatement : IDisposable
    {
        public IntPtr Handle { get; private set; }
        public PreparedStatement(IntPtr handle) => Handle = handle;
        public void Dispose()
        {
            if (Handle == IntPtr.Zero) return;
            Native.sqlite3_finalize(Handle);
            Handle = IntPtr.Zero;
        }
    }

    private static class Native
    {
        private const string Dll = "winsqlite3.dll";
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_open_v2(byte[] filename, out IntPtr ppDb, int flags, IntPtr zVfs);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_close_v2(IntPtr db);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr sqlite3_errmsg(IntPtr db);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_prepare_v2(IntPtr db, byte[] zSql, int nByte, out IntPtr ppStmt, IntPtr pzTail);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_step(IntPtr stmt);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_finalize(IntPtr stmt);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_bind_parameter_index(IntPtr stmt, byte[] zName);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_bind_null(IntPtr stmt, int index);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_bind_int(IntPtr stmt, int index, int value);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_bind_int64(IntPtr stmt, int index, long value);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_bind_double(IntPtr stmt, int index, double value);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_bind_text(IntPtr stmt, int index, byte[] value, int n, IntPtr destructor);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_column_count(IntPtr stmt);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr sqlite3_column_name(IntPtr stmt, int index);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_column_type(IntPtr stmt, int index);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern long sqlite3_column_int64(IntPtr stmt, int index);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern double sqlite3_column_double(IntPtr stmt, int index);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr sqlite3_column_text(IntPtr stmt, int index);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern IntPtr sqlite3_column_blob(IntPtr stmt, int index);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern int sqlite3_column_bytes(IntPtr stmt, int index);
        [DllImport(Dll, CallingConvention = CallingConvention.Cdecl)] internal static extern long sqlite3_last_insert_rowid(IntPtr db);
    }
}
