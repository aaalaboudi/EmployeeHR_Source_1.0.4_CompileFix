using System.Globalization;
using EmployeeHR.Utilities;

namespace EmployeeHR.Data;

public static class Db
{
    internal static SqliteConnectionLite Open() => new(AppPaths.DatabasePath);

    public static string S(object? value) => value?.ToString() ?? "";
    public static long L(object? value) => value is null ? 0 : Convert.ToInt64(value);
    public static int I(object? value) => value is null ? 0 : Convert.ToInt32(value);
    public static decimal D(object? value) => value is null ? 0m : Convert.ToDecimal(value);
    public static bool B(object? value) => I(value) != 0;
    public static DateTime Date(object? value) => DateTime.ParseExact(S(value), "yyyy-MM-dd", CultureInfo.InvariantCulture);
    public static DateTime? DateN(object? value) => string.IsNullOrWhiteSpace(S(value)) ? null : DateTime.ParseExact(S(value), "yyyy-MM-dd", CultureInfo.InvariantCulture);
}
