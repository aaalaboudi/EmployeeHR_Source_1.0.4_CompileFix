using System.Windows;
using System.Windows.Controls;

namespace EmployeeHR.Utilities;

public static class InputDialog
{
    public static string? Show(string prompt,string title,string defaultValue="")
    {
        var w=new Window{Title=title,Width=430,Height=190,WindowStartupLocation=WindowStartupLocation.CenterOwner,ResizeMode=ResizeMode.NoResize,FlowDirection=FlowDirection.RightToLeft};
        var panel=new StackPanel{Margin=new Thickness(14)}; var text=new TextBlock{Text=prompt,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(4)}; var box=new TextBox{Text=defaultValue,Margin=new Thickness(4),MinHeight=32};
        var buttons=new StackPanel{Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Left}; var ok=new Button{Content="موافق",IsDefault=true,MinWidth=80}; var cancel=new Button{Content="إلغاء",IsCancel=true,MinWidth=80};
        ok.Click+=(_,_)=>{w.DialogResult=true;w.Close();}; buttons.Children.Add(ok);buttons.Children.Add(cancel);panel.Children.Add(text);panel.Children.Add(box);panel.Children.Add(buttons);w.Content=panel;box.SelectAll();box.Focus();
        return w.ShowDialog()==true?box.Text:null;
    }
}
