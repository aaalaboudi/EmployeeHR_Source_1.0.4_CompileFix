using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace EmployeeHR.Utilities;

public sealed record RenderedPage(byte[] Jpeg, int PixelWidth, int PixelHeight);

public static class PdfImageWriter
{
    public static RenderedPage Render(FrameworkElement element, int width = 794, int height = 1123)
    {
        element.Measure(new Size(width, height));
        element.Arrange(new Rect(0, 0, width, height));
        element.UpdateLayout();
        var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
        bitmap.Render(element);
        var encoder = new JpegBitmapEncoder { QualityLevel = 90 };
        encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using var ms = new MemoryStream(); encoder.Save(ms);
        return new RenderedPage(ms.ToArray(), width, height);
    }

    public static void Write(string path, IReadOnlyList<RenderedPage> pages)
    {
        if (pages.Count == 0) throw new InvalidOperationException("لا توجد صفحات للتصدير.");
        using var ms = new MemoryStream();
        void W(string s) { var b = Encoding.ASCII.GetBytes(s); ms.Write(b, 0, b.Length); }
        W("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");
        var offsets = new Dictionary<int, long>();
        var maxObj = 2 + pages.Count * 3;
        var kids = string.Join(" ", Enumerable.Range(0, pages.Count).Select(i => $"{3 + i * 3} 0 R"));
        WriteObj(1, "<< /Type /Catalog /Pages 2 0 R >>");
        WriteObj(2, $"<< /Type /Pages /Kids [{kids}] /Count {pages.Count} >>");
        for (var i = 0; i < pages.Count; i++)
        {
            var pageObj = 3 + i * 3; var imageObj = pageObj + 1; var contentObj = pageObj + 2; var p = pages[i];
            WriteObj(pageObj, $"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im0 {imageObj} 0 R >> >> /Contents {contentObj} 0 R >>");
            offsets[imageObj] = ms.Position; W($"{imageObj} 0 obj\n<< /Type /XObject /Subtype /Image /Width {p.PixelWidth} /Height {p.PixelHeight} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length {p.Jpeg.Length} >>\nstream\n"); ms.Write(p.Jpeg, 0, p.Jpeg.Length); W("\nendstream\nendobj\n");
            var content = Encoding.ASCII.GetBytes("q\n595 0 0 842 0 0 cm\n/Im0 Do\nQ\n");
            offsets[contentObj] = ms.Position; W($"{contentObj} 0 obj\n<< /Length {content.Length} >>\nstream\n"); ms.Write(content, 0, content.Length); W("endstream\nendobj\n");
        }
        var xref = ms.Position;
        W($"xref\n0 {maxObj + 1}\n0000000000 65535 f \n");
        for (var i = 1; i <= maxObj; i++) W($"{offsets[i]:D10} 00000 n \n");
        W($"trailer\n<< /Size {maxObj + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF");
        File.WriteAllBytes(path, ms.ToArray());

        void WriteObj(int n, string body)
        {
            offsets[n] = ms.Position; W($"{n} 0 obj\n{body}\nendobj\n");
        }
    }
}
