namespace EmployeeHR.Utilities;

public static class AppPaths
{
    public static string BaseDirectory => AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
    public static string DatabasePath => Path.Combine(BaseDirectory, "EmployeeHR.db");
    public static string BackupsDirectory => Path.Combine(BaseDirectory, "Backups");
    public static string ExportsDirectory => Path.Combine(BaseDirectory, "Exports");

    public static void EnsureWritableStructure()
    {
        Directory.CreateDirectory(BackupsDirectory);
        Directory.CreateDirectory(ExportsDirectory);
        var probe = Path.Combine(BaseDirectory, $".write-test-{Guid.NewGuid():N}.tmp");
        try
        {
            File.WriteAllText(probe, "ok");
            File.Delete(probe);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("يجب تشغيل البرنامج من مجلد قابل للكتابة. انقل مجلد البرنامج إلى USB أو مجلد محلي يسمح بالكتابة.", ex);
        }
    }
}
