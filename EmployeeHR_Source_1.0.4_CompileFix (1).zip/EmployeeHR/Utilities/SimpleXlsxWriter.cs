using System.IO.Compression;
using System.Security;
using System.Text;

namespace EmployeeHR.Utilities;

public static class SimpleXlsxWriter
{
    public static void Write(string path, IEnumerable<string> headers, IEnumerable<IEnumerable<object?>> rows, string sheetName = "Report")
    {
        var h = headers.ToList();
        var data = rows.Select(r => r.ToList()).ToList();
        if (File.Exists(path)) File.Delete(path);
        using var fs = File.Create(path);
        using var zip = new ZipArchive(fs, ZipArchiveMode.Create);
        Add(zip, "[Content_Types].xml",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
            "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
            "</Types>");

        Add(zip, "_rels/.rels",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
            "</Relationships>");

        Add(zip, "xl/workbook.xml",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
            $"<sheets><sheet name=\"{Xml(sheetName)}\" sheetId=\"1\" r:id=\"rId1\"/></sheets>" +
            "</workbook>");

        Add(zip, "xl/_rels/workbook.xml.rels",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
            "</Relationships>");
        var sb = new StringBuilder();
        sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView rightToLeft=\"1\" workbookViewId=\"0\"/></sheetViews><sheetData>");
        AppendRow(sb, 1, h.Cast<object?>().ToList());
        for (var i = 0; i < data.Count; i++) AppendRow(sb, i + 2, data[i]);
        sb.Append("</sheetData></worksheet>");
        Add(zip, "xl/worksheets/sheet1.xml", sb.ToString());
    }

    private static void AppendRow(StringBuilder sb, int rowIndex, IList<object?> values)
    {
        sb.Append($"<row r=\"{rowIndex}\">");
        for (var i = 0; i < values.Count; i++)
        {
            var r = CellRef(i + 1, rowIndex);
            var text = Format(values[i]);
            sb.Append($"<c r=\"{r}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">{Xml(text)}</t></is></c>");
        }
        sb.Append("</row>");
    }

    private static string Format(object? value) => value switch
    {
        null => "",
        DateTime d => d.ToString("yyyy/MM/dd"),
        decimal m => m.ToString("0.00"),
        double d => d.ToString("0.00"),
        _ => Convert.ToString(value) ?? ""
    };

    private static string CellRef(int col, int row)
    {
        var name = "";
        while (col > 0) { col--; name = (char)('A' + col % 26) + name; col /= 26; }
        return name + row;
    }
    private static string Xml(string value) => SecurityElement.Escape(value) ?? "";
    private static void Add(ZipArchive zip, string name, string content)
    {
        var entry = zip.CreateEntry(name, CompressionLevel.Optimal);
        using var s = entry.Open(); using var w = new StreamWriter(s, new UTF8Encoding(false)); w.Write(content);
    }
}
