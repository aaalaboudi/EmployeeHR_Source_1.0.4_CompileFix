using System.Text;
using EmployeeHR.Data;
using EmployeeHR.Models;
using EmployeeHR.Repositories;
using EmployeeHR.Services;

namespace EmployeeHR.Calculation;

public sealed class FinalSettlementService
{
    private readonly EmployeeRepository _employees = new();
    private readonly SalaryService _salary = new();
    private readonly LeaveCalculationService _leave = new();
    private readonly EndOfServiceBenefitService _eosb = new();
    private readonly TerminationService _termination = new();
    private readonly ServicePeriodCalculationService _period = new();

    public FinalSettlementResult Calculate(long employeeId, DateTime? lastWorkingDay = null)
    {
        var employee = _employees.Get(employeeId) ?? throw new InvalidOperationException("الموظف غير موجود.");
        var term = _termination.Get(employeeId);
        var end = (lastWorkingDay ?? term?.LastWorkingDay ?? DateTime.Today).Date;
        var reason = term?.Reason ?? "انتهاء العقد";
        var service = _period.Calculate(employee, end);
        var eosb = _eosb.Calculate(employee, end, reason, false, term?.LegalArticle ?? "");
        var leave = _leave.CalculateBalance(employeeId, end, true);
        var leaveDays = Math.Max(0, leave.CurrentBalance);
        var leaveWage = _salary.GetEligibleWage(employeeId, end, "Leave");
        var divisor = SettingsService.GetDecimal("DailyWageDivisor", 30m);
        if (divisor <= 0) divisor = 30m;
        var leaveDaily = leaveWage / divisor;
        var leaveValue = leaveDays * leaveDaily;
        var gross = _salary.GetEligibleWage(employeeId, end, "Other");
        var salaryDays = CalculatePayableDaysInFinalMonth(employee, end);
        var salaryUntilEnd = gross / divisor * salaryDays;
        var compensation = term?.CompensationAmount ?? 0m;
        var adjustments = GetAdjustments(employeeId, end);
        var result = new FinalSettlementResult
        {
            Employee = employee, LastWorkingDay = end, ServicePeriod = service,
            LastGrossMonthlyWage = Math.Round(gross, 2), EosbEligibleMonthlyWage = Math.Round(eosb.EligibleMonthlyWage, 2), LeaveEligibleMonthlyWage = Math.Round(leaveWage, 2),
            SalaryUntilLastDay = Math.Round(salaryUntilEnd, 2), Eosb = eosb.FinalAward,
            LeaveDays = Math.Round(leaveDays, 2), LeaveDailyRate = Math.Round(leaveDaily, 4), LeaveValue = Math.Round(leaveValue, 2),
            TerminationCompensation = compensation,
            PriorSalaryDue = adjustments.entitlements.GetValueOrDefault("رواتب سابقة مستحقة"),
            AllowancesDue = adjustments.entitlements.GetValueOrDefault("بدلات مستحقة"),
            CommissionsDue = adjustments.entitlements.GetValueOrDefault("عمولات"),
            ExpensesDue = adjustments.entitlements.GetValueOrDefault("مصروفات مستحقة"),
            OtherEntitlements = adjustments.entitlements.Where(x => x.Key is not ("رواتب سابقة مستحقة" or "بدلات مستحقة" or "عمولات" or "مصروفات مستحقة")).Sum(x => x.Value),
            Advances = adjustments.deductions.GetValueOrDefault("سلف"), Loans = adjustments.deductions.GetValueOrDefault("قروض"),
            StatutoryDeductions = adjustments.deductions.GetValueOrDefault("خصومات نظامية"), EmployerReceivables = adjustments.deductions.GetValueOrDefault("مبالغ مستحقة لصاحب العمل"),
            OtherDeductions = adjustments.deductions.Where(x => x.Key is not ("سلف" or "قروض" or "خصومات نظامية" or "مبالغ مستحقة لصاحب العمل")).Sum(x => x.Value)
        };
        var sb = new StringBuilder();
        sb.AppendLine($"مدة الخدمة: {service.Display} ({service.DecimalYears:N6} سنة)");
        sb.AppendLine($"الراتب المستحق حتى آخر يوم عمل: {gross:N2} ÷ {divisor:N2} × {salaryDays:N2} = {result.SalaryUntilLastDay:N2} ريال");
        sb.AppendLine("--- مكافأة نهاية الخدمة ---"); sb.AppendLine(eosb.Details.Trim());
        sb.AppendLine("--- رصيد الإجازة ---"); sb.AppendLine(leave.CalculationDetails.Trim());
        sb.AppendLine($"قيمة يوم الإجازة: {leaveWage:N2} ÷ {divisor:N2} = {leaveDaily:N4} ريال");
        sb.AppendLine($"قيمة رصيد الإجازة: {leaveDays:N2} × {leaveDaily:N4} = {leaveValue:N2} ريال");
        sb.AppendLine($"تعويض إنهاء العقد (مستقل عن المكافأة): {compensation:N2} ريال");
        sb.AppendLine($"إجمالي المستحقات: {result.TotalEntitlements:N2} ريال");
        sb.AppendLine($"إجمالي الخصومات: {result.TotalDeductions:N2} ريال");
        sb.AppendLine($"صافي التصفية: {result.NetSettlement:N2} ريال");
        result.CalculationDetails = sb.ToString();
        return result;
    }

    public void AddAdjustment(long employeeId, string category, string description, decimal amount, bool isDeduction, DateTime effectiveDate, string notes = "")
    {
        if (amount < 0) throw new InvalidOperationException("أدخل المبلغ بقيمة موجبة وحدد ما إذا كان خصمًا.");
        using var db = Db.Open();
        var id = db.ExecuteInsert(@"INSERT INTO SettlementAdjustments(EmployeeId,Category,Description,Amount,IsDeduction,EffectiveDate,Notes) VALUES(@e,@c,@d,@a,@i,@f,@n);", new Dictionary<string, object?> { ["e"] = employeeId,["c"] = category,["d"] = description,["a"] = amount,["i"] = isDeduction,["f"] = effectiveDate,["n"] = notes });
        AuditService.Log("إضافة بند تصفية", "SettlementAdjustment", id.ToString(), $"{category}: {amount:N2} {(isDeduction ? "خصم" : "مستحق")}");
    }

    public List<Dictionary<string, object?>> GetAdjustmentRows(long employeeId)
    {
        using var db = Db.Open();
        return db.Query(@"SELECT Id,Category 'الفئة',Description 'البيان',Amount 'المبلغ',CASE WHEN IsDeduction=1 THEN 'خصم' ELSE 'مستحق' END 'النوع',EffectiveDate 'التاريخ',Notes 'ملاحظات' FROM SettlementAdjustments WHERE EmployeeId=@e ORDER BY EffectiveDate,Id;", new Dictionary<string, object?> { ["e"] = employeeId });
    }

    private decimal CalculatePayableDaysInFinalMonth(Employee employee, DateTime end)
    {
        var start = new DateTime(end.Year, end.Month, 1);
        if (employee.StartDate.Date > start) start = employee.StartDate.Date;
        if (start > end) return 0;
        var calendar = (end - start).Days + 1;
        using var db = Db.Open();
        var unpaid = db.Query(@"SELECT StartDate,EndDate FROM UnpaidLeaves WHERE EmployeeId=@e AND EndDate>=@s AND StartDate<=@d;", new Dictionary<string, object?> { ["e"] = employee.Id,["s"] = start,["d"] = end });
        var excluded = new HashSet<DateTime>();
        foreach (var r in unpaid)
        {
            var a = Db.Date(r["StartDate"]); var b = Db.Date(r["EndDate"]);
            if (a < start) a = start; if (b > end) b = end;
            for (var d = a; d <= b; d = d.AddDays(1)) excluded.Add(d);
        }
        return Math.Max(0, calendar - excluded.Count);
    }

    private (Dictionary<string, decimal> entitlements, Dictionary<string, decimal> deductions) GetAdjustments(long employeeId, DateTime end)
    {
        using var db = Db.Open();
        var rows = db.Query("SELECT Category,Amount,IsDeduction FROM SettlementAdjustments WHERE EmployeeId=@e AND EffectiveDate<=@d;", new Dictionary<string, object?> { ["e"] = employeeId,["d"] = end });
        var e = new Dictionary<string, decimal>(); var d = new Dictionary<string, decimal>();
        foreach (var r in rows)
        {
            var target = Db.B(r["IsDeduction"]) ? d : e; var key = Db.S(r["Category"]); target[key] = target.GetValueOrDefault(key) + Db.D(r["Amount"]);
        }
        return (e, d);
    }
}
