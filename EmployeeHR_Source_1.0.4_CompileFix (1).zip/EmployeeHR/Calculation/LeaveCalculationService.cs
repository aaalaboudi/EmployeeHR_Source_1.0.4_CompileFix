using System.Text;
using EmployeeHR.Models;
using EmployeeHR.Repositories;
using EmployeeHR.Services;

namespace EmployeeHR.Calculation;

public sealed class LeaveCalculationService
{
    private readonly EmployeeRepository _employeeRepo = new();
    private readonly LeaveRepository _leaveRepo = new();
    private readonly RulesRepository _rulesRepo = new();
    private readonly ServicePeriodCalculationService _servicePeriod = new();

    public int CountLeaveDays(DateTime start, DateTime end)
    {
        if (end.Date < start.Date) throw new InvalidOperationException("تاريخ نهاية الإجازة يسبق تاريخ البداية.");
        var mode = SettingsService.Get("LeaveDayMode", "CalendarDays");
        if (mode.Equals("CalendarDays", StringComparison.OrdinalIgnoreCase))
            return (end.Date - start.Date).Days + 1;

        var weekends = SettingsService.Get("WeekendDays", "Friday,Saturday")
            .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(ParseDayOfWeek).ToHashSet();
        var count = 0;
        for (var d = start.Date; d <= end.Date; d = d.AddDays(1))
            if (!weekends.Contains(d.DayOfWeek)) count++;
        return count;
    }

    public LeaveBalanceResult CalculateBalance(long employeeId, DateTime asOf, bool rebuildLedger = true)
    {
        var employee = _employeeRepo.Get(employeeId) ?? throw new InvalidOperationException("الموظف غير موجود.");
        var terminationDate = GetTerminationDate(employeeId);
        if (terminationDate.HasValue && asOf.Date > terminationDate.Value.Date) asOf = terminationDate.Value.Date;
        if (asOf.Date < employee.StartDate.Date) return new LeaveBalanceResult();

        if (rebuildLedger) RebuildSystemLedger(employee, asOf);
        var ledger = _leaveRepo.GetLedger(employeeId, asOf);
        var opening = ledger.Where(x => x.EntryType == "رصيد افتتاحي").Sum(x => x.Adjustment);
        var accrued = ledger.Where(x => x.SystemGenerated && x.EntryType == "استحقاق").Sum(x => x.Accrued);
        var used = ledger.Where(x => x.SystemGenerated && x.EntryType == "استخدام إجازة").Sum(x => x.Used);
        var adjustments = ledger.Where(x => !x.SystemGenerated && x.EntryType != "رصيد افتتاحي").Sum(x => x.Adjustment);
        var future = _leaveRepo.GetByEmployee(employeeId).Where(x => x.Status == "معتمدة" && x.StartDate.Date > asOf.Date).Sum(x => x.DaysCount);
        var details = new StringBuilder();
        details.AppendLine($"الرصيد الافتتاحي: {opening:N2} يوم");
        details.AppendLine($"الاستحقاق حتى {asOf:yyyy/MM/dd}: {accrued:N2} يوم");
        details.AppendLine($"الإجازة المستخدمة: {used:N2} يوم");
        details.AppendLine($"التعديلات اليدوية: {adjustments:N2} يوم");
        details.AppendLine($"الرصيد الحالي = {opening:N2} + {accrued:N2} + {adjustments:N2} - {used:N2} = {(opening + accrued + adjustments - used):N2} يوم");
        details.AppendLine($"الإجازات المستقبلية المعتمدة (لا تخصم من الرصيد الحالي): {future:N2} يوم");
        return new LeaveBalanceResult { OpeningBalance = opening, Accrued = accrued, Used = used, Adjustments = adjustments, FutureApproved = future, CalculationDetails = details.ToString() };
    }

    public List<LeaveLedgerEntry> GetLedger(long employeeId, DateTime asOf)
    {
        CalculateBalance(employeeId, asOf, true);
        return _leaveRepo.GetLedger(employeeId, asOf);
    }

    public void AddAdjustment(long employeeId, DateTime date, decimal amount, string description)
    {
        _leaveRepo.AddAdjustment(employeeId, date, amount, string.IsNullOrWhiteSpace(description) ? "تعديل يدوي" : description);
        AuditService.Log("تعديل رصيد إجازة", "LeaveLedger", employeeId.ToString(), $"{amount:+0.00;-0.00;0.00} يوم - {description}");
    }

    public void SetOpeningBalance(long employeeId, DateTime date, decimal amount, string description = "رصيد افتتاحي")
    {
        _leaveRepo.SetOpeningBalance(employeeId,date,amount,string.IsNullOrWhiteSpace(description)?"رصيد افتتاحي":description);
        AuditService.Log("تعيين رصيد افتتاحي للإجازة","LeaveLedger",employeeId.ToString(),$"{amount:N2} يوم - {description}");
    }

    private void RebuildSystemLedger(Employee employee, DateTime asOf)
    {
        var entries = new List<LeaveLedgerEntry>();
        var allUnpaid = _leaveRepo.GetUnpaid(employee.Id);
        var leaveExcluded = allUnpaid.Where(x => x.AffectsLeaveAccrual).ToList();
        var serviceExcluded = allUnpaid.Where(x => x.AffectsService).ToList();
        var monthlyAccrual = new Dictionary<DateTime, decimal>();
        var netServiceDays = 0;

        for (var d = employee.StartDate.Date; d <= asOf.Date; d = d.AddDays(1))
        {
            var excludedFromService = serviceExcluded.Any(x => d >= x.StartDate.Date && d <= x.EndDate.Date);
            if (!excludedFromService) netServiceDays++;
            if (leaveExcluded.Any(x => d >= x.StartDate.Date && d <= x.EndDate.Date)) continue;
            // Determine the entitlement tier from completed net service at the start of the day.
            // This prevents the 30-day tier from starting one day before five full years have been completed.
            var completedNetYearsBeforeDay = ServiceYearsForNetDays(employee.StartDate.Date, Math.Max(0, netServiceDays - (excludedFromService ? 0 : 1)));
            var rule = ResolveLeaveRule(completedNetYearsBeforeDay, d);
            if (rule is null) continue;
            var serviceYearStart = ServiceYearStart(employee.StartDate.Date, d);
            var serviceYearEnd = serviceYearStart.AddYears(1);
            var denominator = (serviceYearEnd - serviceYearStart).Days;
            var daily = rule.Days / denominator;
            var key = new DateTime(d.Year, d.Month, DateTime.DaysInMonth(d.Year, d.Month));
            if (key > asOf.Date) key = asOf.Date;
            monthlyAccrual[key] = monthlyAccrual.GetValueOrDefault(key) + daily;
        }

        foreach (var item in monthlyAccrual.OrderBy(x => x.Key))
            entries.Add(new LeaveLedgerEntry { EmployeeId = employee.Id, EntryDate = item.Key, EntryType = "استحقاق", Description = "استحقاق إجازة سنوية محسوب Pro-Rata", Accrued = Math.Round(item.Value, 8), SystemGenerated = true });

        foreach (var leave in _leaveRepo.GetByEmployee(employee.Id).Where(x => x.Status == "معتمدة" && x.StartDate.Date <= asOf.Date))
        {
            var usedThroughAsOf = leave.EndDate.Date <= asOf.Date ? leave.DaysCount : CountLeaveDays(leave.StartDate, asOf);
            entries.Add(new LeaveLedgerEntry { EmployeeId = employee.Id, EntryDate = leave.StartDate.Date, EntryType = "استخدام إجازة", Description = $"{leave.LeaveType} من {leave.StartDate:yyyy/MM/dd} إلى {leave.EndDate:yyyy/MM/dd}", Used = usedThroughAsOf, SystemGenerated = true, SourceId = leave.Id });
        }
        _leaveRepo.ReplaceSystemLedger(employee.Id, entries);
    }

    private LeaveRule? ResolveLeaveRule(decimal serviceYears, DateTime date)
        => _rulesRepo.GetLeaveRules().Where(r => r.EffectiveFrom <= date && (!r.EffectiveTo.HasValue || r.EffectiveTo.Value >= date) && serviceYears >= r.MinYears && (!r.MaxYears.HasValue || serviceYears < r.MaxYears.Value)).OrderByDescending(r => r.EffectiveFrom).FirstOrDefault();

    private DateTime? GetTerminationDate(long employeeId)
    {
        using var db = EmployeeHR.Data.Db.Open();
        var v = db.Scalar("SELECT LastWorkingDay FROM Terminations WHERE EmployeeId=@e LIMIT 1;", new Dictionary<string, object?> { ["e"] = employeeId });
        return EmployeeHR.Data.Db.DateN(v);
    }

    private static DateTime ServiceYearStart(DateTime employmentStart, DateTime d)
    {
        var year = d.Year;
        DateTime candidate;
        try { candidate = new DateTime(year, employmentStart.Month, employmentStart.Day); }
        catch { candidate = new DateTime(year, employmentStart.Month, DateTime.DaysInMonth(year, employmentStart.Month)); }
        if (candidate > d)
        {
            year--;
            try { candidate = new DateTime(year, employmentStart.Month, employmentStart.Day); }
            catch { candidate = new DateTime(year, employmentStart.Month, DateTime.DaysInMonth(year, employmentStart.Month)); }
        }
        return candidate;
    }

    private static decimal ServiceYearsForNetDays(DateTime start, int netDays)
    {
        if (netDays <= 0) return 0m;
        var syntheticEnd = start.AddDays(netDays - 1);
        decimal years = 0m;
        var periodStart = start;
        var index = 1;
        var endExclusive = syntheticEnd.AddDays(1);
        while (periodStart < endExclusive)
        {
            var nominalNext = start.AddYears(index++);
            var segmentEnd = nominalNext < endExclusive ? nominalNext : endExclusive;
            var denom = (nominalNext - periodStart).Days;
            years += (decimal)(segmentEnd - periodStart).Days / denom;
            periodStart = segmentEnd;
        }
        return years;
    }

    private static DayOfWeek ParseDayOfWeek(string value) => value.Trim().ToLowerInvariant() switch
    {
        "sunday" or "الأحد" => DayOfWeek.Sunday,
        "monday" or "الاثنين" => DayOfWeek.Monday,
        "tuesday" or "الثلاثاء" => DayOfWeek.Tuesday,
        "wednesday" or "الأربعاء" => DayOfWeek.Wednesday,
        "thursday" or "الخميس" => DayOfWeek.Thursday,
        "friday" or "الجمعة" => DayOfWeek.Friday,
        "saturday" or "السبت" => DayOfWeek.Saturday,
        _ => DayOfWeek.Friday
    };
}
