using System.Text;
using EmployeeHR.Models;
using EmployeeHR.Services;

namespace EmployeeHR.Calculation;

public sealed record TerminationCompensationResult(decimal Amount, string Method, string Details);

public sealed class TerminationCompensationService
{
    private readonly SalaryService _salary = new();
    private readonly ServicePeriodCalculationService _period = new();

    /// <summary>
    /// Calculates an indicative Article 77 amount only when the user has already decided
    /// that Article 77 is relevant to the case. It does not decide legal entitlement.
    /// </summary>
    public TerminationCompensationResult CalculateArticle77(Employee employee, DateTime lastWorkingDay)
    {
        var end = lastWorkingDay.Date;
        if (end < employee.StartDate.Date) throw new InvalidOperationException("آخر يوم عمل يسبق بداية الخدمة.");

        var wage = _salary.GetEligibleWage(employee.Id, end, "Other");
        if (wage <= 0) throw new InvalidOperationException("لا يوجد أجر صالح للحساب في تاريخ انتهاء الخدمة.");
        var divisor = SettingsService.GetDecimal("DailyWageDivisor", 30m);
        if (divisor <= 0) divisor = 30m;
        var dailyWage = wage / divisor;
        var minimum = wage * 2m;
        decimal raw;
        string method;
        var sb = new StringBuilder();
        sb.AppendLine("هذا احتساب استرشادي للمادة 77 فقط بعد أن يقرر المستخدم انطباقها على الحالة.");
        sb.AppendLine($"الأجر المستخدم: {wage:N2} ريال. قيمة اليوم على مقسوم {divisor:N2}: {dailyWage:N4} ريال.");

        if (employee.ContractType.Contains("غير محدد", StringComparison.OrdinalIgnoreCase))
        {
            var service = _period.Calculate(employee, end);
            raw = dailyWage * 15m * service.DecimalYears;
            method = "عقد غير محدد المدة: أجر 15 يومًا عن كل سنة خدمة وفق المادة 77، مع حد أدنى أجر شهرين عند انطباق المادة.";
            sb.AppendLine($"أجر 15 يومًا × مدة الخدمة: {dailyWage:N4} × 15 × {service.DecimalYears:N6} = {raw:N2} ريال.");
        }
        else
        {
            if (!employee.ContractEnd.HasValue) throw new InvalidOperationException("العقد محدد المدة ولا يوجد تاريخ نهاية عقد مسجل.");
            var contractEnd = employee.ContractEnd.Value.Date;
            if (contractEnd <= end) throw new InvalidOperationException("لا توجد مدة عقد متبقية بعد آخر يوم عمل؛ راجع انطباق المادة 77 على الحالة.");
            var remainingDays = (contractEnd - end).Days;
            raw = dailyWage * remainingDays;
            method = "عقد محدد المدة: أجر المدة المتبقية من العقد وفق المادة 77، مع حد أدنى أجر شهرين عند انطباق المادة.";
            sb.AppendLine($"المدة المتبقية: {remainingDays:N0} يوم. {dailyWage:N4} × {remainingDays:N0} = {raw:N2} ريال.");
        }

        var amount = Math.Max(raw, minimum);
        sb.AppendLine($"الحد الأدنى الاسترشادي لأجر شهرين: {minimum:N2} ريال.");
        sb.AppendLine($"القيمة الاسترشادية الأعلى: {amount:N2} ريال.");
        sb.AppendLine("إذا كان العقد يتضمن تعويضًا محددًا، أو كانت المادة 77 غير منطبقة على الوقائع، فلا تعتمد هذه النتيجة تلقائيًا.");
        return new TerminationCompensationResult(Math.Round(amount, 2), method, sb.ToString());
    }
}
