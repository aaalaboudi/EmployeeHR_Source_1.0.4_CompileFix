using EmployeeHR.Models;
using EmployeeHR.Repositories;

namespace EmployeeHR.Calculation;

public sealed class ServicePeriodCalculationService
{
    private readonly LeaveRepository _leaveRepo = new();

    public ServicePeriodResult Calculate(Employee employee, DateTime endDate)
    {
        var start = employee.StartDate.Date;
        var end = endDate.Date;
        if (end < start) throw new InvalidOperationException("تاريخ نهاية الخدمة يسبق تاريخ بداية الخدمة.");

        var excludedRanges = _leaveRepo.GetUnpaid(employee.Id)
            .Where(x => x.AffectsService && x.EndDate.Date >= start && x.StartDate.Date <= end)
            .Select(x => (Start: x.StartDate.Date < start ? start : x.StartDate.Date, End: x.EndDate.Date > end ? end : x.EndDate.Date))
            .ToList();

        var totalDays = (end - start).Days + 1;
        var excludedDays = CountUnionDays(excludedRanges);
        var netDays = Math.Max(0, totalDays - excludedDays);
        var decimalYears = CalculateYearFraction(start, end, excludedRanges);
        var (years, months, days) = ToCalendarLikeDuration(start, netDays);

        return new ServicePeriodResult
        {
            TotalCalendarDays = totalDays,
            ExcludedDays = excludedDays,
            NetServiceDays = netDays,
            Years = years,
            Months = months,
            Days = days,
            DecimalYears = Math.Round(decimalYears, 8)
        };
    }

    public decimal CalculateNetYearsAt(Employee employee, DateTime asOf)
    {
        if (asOf.Date < employee.StartDate.Date) return 0;
        return Calculate(employee, asOf).DecimalYears;
    }

    private static decimal CalculateYearFraction(DateTime start, DateTime end, List<(DateTime Start, DateTime End)> excluded)
    {
        decimal years = 0;
        var periodStart = start;
        var anniversaryIndex = 1;
        var endExclusive = end.AddDays(1);
        while (periodStart < endExclusive)
        {
            var nominalNext = SafeAddYears(start, anniversaryIndex++);
            var periodEndExclusive = nominalNext < endExclusive ? nominalNext : endExclusive;
            var denominator = (nominalNext - periodStart).Days;
            if (denominator <= 0) denominator = 365;
            var calendarDays = (periodEndExclusive - periodStart).Days;
            var periodEndInclusive = periodEndExclusive.AddDays(-1);
            var excludedDays = CountUnionDays(excluded.Select(x => (x.Start < periodStart ? periodStart : x.Start, x.End > periodEndInclusive ? periodEndInclusive : x.End)).Where(x => x.Item2 >= x.Item1));
            var eligibleDays = Math.Max(0, calendarDays - excludedDays);
            years += (decimal)eligibleDays / denominator;
            periodStart = periodEndExclusive;
        }
        return years;
    }

    private static DateTime SafeAddYears(DateTime d, int years)
    {
        try { return d.AddYears(years); }
        catch { return new DateTime(d.Year + years, d.Month, DateTime.DaysInMonth(d.Year + years, d.Month)); }
    }

    private static int CountUnionDays(IEnumerable<(DateTime Start, DateTime End)> ranges)
    {
        var ordered = ranges.Where(x => x.End >= x.Start).OrderBy(x => x.Start).ToList();
        if (ordered.Count == 0) return 0;
        var total = 0;
        var s = ordered[0].Start;
        var e = ordered[0].End;
        for (var i = 1; i < ordered.Count; i++)
        {
            var r = ordered[i];
            if (r.Start <= e.AddDays(1))
            {
                if (r.End > e) e = r.End;
            }
            else
            {
                total += (e - s).Days + 1;
                s = r.Start; e = r.End;
            }
        }
        total += (e - s).Days + 1;
        return total;
    }

    private static (int years, int months, int days) ToCalendarLikeDuration(DateTime start, int netDays)
    {
        if (netDays <= 0) return (0, 0, 0);
        // Service days are inclusive of the last working day. Converting to an exclusive
        // synthetic endpoint makes a full anniversary display as an exact year.
        var syntheticEndExclusive = start.AddDays(netDays);
        var years = syntheticEndExclusive.Year - start.Year;
        var anchor = SafeAddYears(start, years);
        if (anchor > syntheticEndExclusive) { years--; anchor = SafeAddYears(start, years); }
        var months = 0;
        while (months < 11 && anchor.AddMonths(months + 1) <= syntheticEndExclusive) months++;
        var monthAnchor = anchor.AddMonths(months);
        var days = (syntheticEndExclusive - monthAnchor).Days;
        return (Math.Max(0, years), months, days);
    }
}
