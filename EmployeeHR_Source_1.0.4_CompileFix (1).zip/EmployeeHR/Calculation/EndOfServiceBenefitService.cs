using System.Text;
using EmployeeHR.Models;
using EmployeeHR.Repositories;
using EmployeeHR.Services;

namespace EmployeeHR.Calculation;

public sealed class EndOfServiceBenefitService
{
    private readonly ServicePeriodCalculationService _period = new();
    private readonly RulesRepository _rules = new();
    private readonly SalaryService _salary = new();

    public EosbResult Calculate(Employee employee, DateTime lastWorkingDay, string terminationReason, bool forceFullEntitlement = false, string legalArticle = "")
    {
        var period = _period.Calculate(employee, lastWorkingDay);
        var wage = _salary.GetEligibleWage(employee.Id, lastWorkingDay, "EOSB");
        var eosbRules = _rules.GetEosbRules().Where(x => x.EffectiveFrom <= lastWorkingDay && (!x.EffectiveTo.HasValue || x.EffectiveTo.Value >= lastWorkingDay)).OrderBy(x => x.StartYears).ToList();
        decimal basic = 0, first = 0, after = 0;
        foreach (var rule in eosbRules)
        {
            var end = rule.EndYears ?? period.DecimalYears;
            var segmentYears = Math.Max(0, Math.Min(period.DecimalYears, end) - rule.StartYears);
            if (segmentYears <= 0) continue;
            var amount = wage * rule.MonthsPerYear * segmentYears;
            basic += amount;
            if (rule.StartYears < 5) first += amount; else after += amount;
        }

        decimal rate = 1m;
        var noAward = terminationReason.Contains("فترة التجربة", StringComparison.OrdinalIgnoreCase) || legalArticle.Contains("54", StringComparison.OrdinalIgnoreCase) || legalArticle.Contains("80", StringComparison.OrdinalIgnoreCase) || terminationReason.Contains("المادة 80", StringComparison.OrdinalIgnoreCase);
        var isResignation = terminationReason.Contains("استقال", StringComparison.OrdinalIgnoreCase);
        var reasonDef = _rules.GetTerminationReasons().FirstOrDefault(x => x.Name == terminationReason);
        if (isResignation && !forceFullEntitlement && !(reasonDef?.FullEosbException ?? false))
        {
            var rr = _rules.GetResignationRules().Where(x => x.EffectiveFrom <= lastWorkingDay && (!x.EffectiveTo.HasValue || x.EffectiveTo.Value >= lastWorkingDay)
                && (x.MinInclusive ? period.DecimalYears >= x.MinYears : period.DecimalYears > x.MinYears)
                && (!x.MaxYears.HasValue || (x.MaxInclusive ? period.DecimalYears <= x.MaxYears.Value : period.DecimalYears < x.MaxYears.Value))).OrderByDescending(x => x.EffectiveFrom).FirstOrDefault();
            rate = rr?.Rate ?? 0m;
        }
        if (forceFullEntitlement || (reasonDef?.FullEosbException ?? false)) rate = 1m;
        if (noAward) rate = 0m;
        var final = basic * rate;

        var details = new StringBuilder();
        details.AppendLine($"مدة الخدمة الصافية: {period.Display} ({period.DecimalYears:N6} سنة)");
        if (period.ExcludedDays > 0) details.AppendLine($"الفترات المستبعدة من الخدمة: {period.ExcludedDays:N0} يوم");
        details.AppendLine("مكونات الأجر عند تاريخ انتهاء الخدمة:");
        foreach (var c in _salary.GetWageBreakdown(employee.Id,lastWorkingDay,"EOSB"))
            details.AppendLine($"- {c.Name}: {c.Amount:N2} ريال ({(c.Included ? "داخل الحساب" : "غير داخل الحساب")})");
        details.AppendLine($"إجمالي الأجر الشهري المؤهل للمكافأة: {wage:N2} ريال");
        details.AppendLine($"مكافأة أول خمس سنوات: {first:N2} ريال");
        details.AppendLine($"مكافأة ما بعد خمس سنوات: {after:N2} ريال");
        details.AppendLine($"إجمالي المكافأة الأساسية: {basic:N2} ريال");
        if (noAward) details.AppendLine("الحالة: لا تستحق مكافأة نهاية خدمة وفق المادة 54 (إنهاء أثناء التجربة) أو المادة 80 بحسب المادة المدخلة.");
        details.AppendLine($"نسبة الاستحقاق: {rate:P2}");
        details.AppendLine($"المكافأة النهائية: {final:N2} ريال");
        return new EosbResult { EligibleMonthlyWage = wage, ServicePeriod = period, FirstFiveYearsAmount = Math.Round(first, 2), YearsAboveFiveAmount = Math.Round(after, 2), BasicAward = Math.Round(basic, 2), EntitlementRate = rate, FinalAward = Math.Round(final, 2), Details = details.ToString() };
    }
}
