@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo EmployeeHR Portable Builder
echo ============================================================
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build-Portable.ps1"

if errorlevel 1 (
  echo.
  echo ============================================================
  echo BUILD FAILED
  echo Please copy the error messages above and send them to ChatGPT.
  echo ============================================================
  pause
  exit /b 1
)

echo.
echo ============================================================
echo BUILD COMPLETED SUCCESSFULLY
echo Open: Release\EmployeeHR_Portable\EmployeeHR.exe
echo ============================================================
pause
exit /b 0
