using System.Globalization;
using System.Windows;
using EmployeeHR.Data;
using EmployeeHR.Services;
using EmployeeHR.Utilities;

namespace EmployeeHR;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        var culture = new CultureInfo("ar-SA");
        culture.DateTimeFormat.Calendar = new GregorianCalendar();
        CultureInfo.DefaultThreadCurrentCulture = culture;
        CultureInfo.DefaultThreadCurrentUICulture = new CultureInfo("ar-SA");
        AppPaths.EnsureWritableStructure();
        DatabaseMigrationService.Initialize();
        try { BackupService.CreateBackup("startup", silent: true); } catch { }
        base.OnStartup(e);
    }

    protected override void OnExit(ExitEventArgs e)
    {
        try { BackupService.CreateBackup("exit", silent: true); } catch { }
        base.OnExit(e);
    }
}
